/**
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9342 TF 9:00-10:30
 * Date: 10/20/2023
 * TreeNode class represents the nodes of the Huffman tree.
 * It implements Comparable to allow for comparison based on the count attribute.
 */
import java.lang.Comparable;

public class TreeNode implements Comparable<TreeNode> {
    private int count;              // Frequency of the symbol
    private char symbol;            // The symbol itself
    private TreeNode left;          // Left child
    private TreeNode right;         // Right child

    /**
     * Default constructor initializes the node with default values.
     * Count is set to 0, symbol is set to 'x', and left and right children are null.
     */
    public TreeNode() {
        count = 0;
        symbol = 'x';
        left = null;
        right = null;
    }

    /**
     * Parameterized constructor to initialize the node with given values.
     * @param count    The frequency of the symbol.
     * @param symbol   The character symbol.
     * @param left     Left child node.
     * @param right    Right child node.
     */
    public TreeNode(int count, char symbol, TreeNode left, TreeNode right) {
        this.count = count;
        this.symbol = symbol;
        this.left = left;
        this.right = right;
    }

    /**
     * Set the frequency count of the symbol.
     * @param count    The frequency to set.
     */
    public void setCount(int count) {
        this.count = count;
    }

    /**
     * Get the frequency count of the symbol.
     * @return  The frequency count.
     */
    public int getCount() {
        return count;
    }

    /**
     * Set the character symbol for the node.
     * @param symbol   The character symbol to set.
     */
    public void setSymbol(char symbol) {
        this.symbol = symbol;
    }

    /**
     * Get the character symbol of the node.
     * @return  The character symbol.
     */
    public char getSymbol() {
        return symbol;
    }

    /**
     * Set the left child node.
     * @param left  The left child node to set.
     */
    public void setLeft(TreeNode left) {
        this.left = left;
    }

    /**
     * Get the left child node.
     * @return  The left child node.
     */
    public TreeNode getLeft() {
        return left;
    }

    /**
     * Set the right child node.
     * @param right  The right child node to set.
     */
    public void setRight(TreeNode right) {
        this.right = right;
    }

    /**
     * Get the right child node.
     * @return  The right child node.
     */
    public TreeNode getRight() {
        return right;
    }

    /**
     * Compare the current TreeNode with another based on the frequency count.
     * Returns:
     *  0  if the frequencies are equal.
     * -1  if the current node's frequency is less than the other's.
     *  1  if the current node's frequency is greater than the other's.
     * @param other   The TreeNode to compare with.
     * @return        The result of the comparison.
     */
    public int compareTo(TreeNode other) {
        if (this.getCount() == other.getCount())
            return 0;
        else if (this.getCount() < other.getCount())
            return -1;
        else
            return 1;
    }
} // end of TreeNode class
