/*
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9342 TF 9:00-10:30
 * Date: 10/20/2023
 */

/**
 * HuffmanTest class builds the Huffman tree and prints the Huffman codes.
 *
 * Algorithm for Huffman Coding:
 *
 * 1. Define a TreeNode class:
 * 2. Each TreeNode has an associated symbol, frequency count, and left and right children.
 * 3. The TreeNode class can be compared to another TreeNode based on its frequency.
 *
 * 4. Define a HuffmanTest class to construct the Huffman tree and print the Huffman codes:
 * 5. Initialize a list of symbols and their corresponding frequencies.
 * 6. Use a priority queue (min-heap) to create and manage the Huffman tree nodes:
 * 7. For each symbol-frequency pair:
 *    - Create a new TreeNode.
 *    - Add the TreeNode to the priority queue.
 * 8. While there's more than one node in the priority queue:
 *    - Remove the two nodes with the lowest frequencies.
 *    - Create a new parent node with these two nodes as children and the sum of their frequencies as its frequency.
 *    - Add this new node back to the priority queue.
 * 9. The last node remaining in the priority queue is the root of the Huffman tree.
 * 10. Recursively traverse the Huffman tree:
 * 11. If you move to the left child, append '0' to the Huffman code.
 * 12. If you move to the right child, append '1' to the Huffman code.
 * 13. If a leaf node is reached (i.e., a node with a symbol), print the symbol and its Huffman code.
 */

/*
 Char | Huffman code
---------------------
F | 00000
G | 00001
H | 0001
B | 001
A | 01
C | 100
D | 101
E | 11

Tested By: Hannah Ragudos

Process finished with exit code 0

 */
import java.util.PriorityQueue;

public class HuffmanTest {

    /**
     * Recursive method to print the Huffman code for each symbol.
     * If a node is a leaf node and contains a letter, its Huffman code is printed.
     * Otherwise, the method is called recursively for the left child (with an added '0')
     * and the right child (with an added '1').
     * @param root  The current node being processed.
     * @param s     The Huffman code constructed so far.
     */
    public static void printCode(TreeNode root, String s) {
        if (root.getLeft() == null && root.getRight() == null && Character.isLetter(root.getSymbol())) {
            System.out.println(root.getSymbol() + " | " + s);
            return;
        }
        printCode(root.getLeft(), s + "0");
        printCode(root.getRight(), s + "1");
    }

    /**
     * The main method to build the Huffman tree and print the Huffman codes.
     * The method initializes a symbol array and its corresponding frequency array.
     * It then builds the Huffman tree using a priority queue.
     * Finally, it prints the Huffman codes for each symbol.
     * @param args  The command line arguments (not used in this implementation).
     */
    public static void main(String[] args) {
        int n = 8;
        char[] symbolArray = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'};
        int[] symbolFrequency = {30, 12, 13, 20, 45, 2, 2, 7};

        PriorityQueue<TreeNode> huffmanTree = new PriorityQueue<TreeNode>(n);
        for (int i = 0; i < n; i++) {
            TreeNode huffmanNode = new TreeNode();
            huffmanNode.setSymbol(symbolArray[i]);
            huffmanNode.setCount(symbolFrequency[i]);
            huffmanTree.add(huffmanNode);
        }

        while (huffmanTree.size() > 1) {
            TreeNode t = huffmanTree.poll();
            TreeNode u = huffmanTree.poll();

            TreeNode v = new TreeNode();
            v.setCount(t.getCount() + u.getCount());
            v.setSymbol('-');  // Temporary symbol for internal nodes
            v.setLeft(t);
            v.setRight(u);

            huffmanTree.add(v);
        }

        TreeNode root = huffmanTree.peek();
        System.out.println(" Char | Huffman code ");
        System.out.println("---------------------");
        printCode(root, "");
        System.out.println();
        System.out.println("Tested By: Hannah Ragudos");
    }
} // end of HuffmanTest class
