/*
Name: Ragudos, Hannah T.
Date: 10/10/2023
 */

/**
 * The following class is a template for a term of an algebraic polynomial that involves one literal.
 * 3x^2 is an example f a term
 * where 3 is the numerical coefficient,
 * x is the literal coefficient and
 * 2 is the degree
 */

public class Term implements Comparable <Term> {
    private double coefficient;
    private int degree;
    private char literal;

    /**
     * Constructs a term with coefficient set to 0, degree set to 0 and literal set to x.
     */
    public Term() {
        coefficient = 0;
        degree = 0;
        literal = 'x';
    }

    /**
     * Constructs a term that sets coefficient, literal and degree
     * to given the coef, literal and degree
     */

    public Term(double coef, char literal, int degree) {
        this.coefficient = coef;
        this.literal = literal;
        this.degree = degree;
    }

    /**
     * Sets the value of the numerical coefficient of this term to the specified coef
     */
    public void setCoefficient(double coefficient) {
        this.coefficient = coefficient;
    }

    /**
     * Sets the value of the degree to a specified degree
     */

    public void setDegree(int degree) {
        this.degree = degree;
    }

    /**
     * Returns the numerical coefficient of this term
     */
    public double getCoefficient() {
        return coefficient;
    }

    /**
     * Returns the literal coefficient of this term
     */
    public char getLiteral() {
        return literal;
    }

    /**
     * Returns the degree f this term
     */
    public int getDegree() {
        return this.degree;
    }

    /**
     * Returns 0 if the degree of this term is equal to the degree of another term
     * else returns an integer that is greater than 0 if the degree of this term is
     * greater than the degree of another term else returns an integer that is lesser than
     * 0 if the degree of this term is lower than the degree of another term.
     */

    @Override
    public int compareTo(Term another) {
        if (this.getDegree() == another.getDegree())
            return 0;
        else if (this.getDegree() > another.getDegree())
            return -1;
        else return 1;
    }
    /**
     * Returns a string representation of the term
     * that follows a format with the exampple 3x^2
     */

    public String toString () {
        if (coefficient == 0)
            return "";
        else
            if (coefficient==1&&degree==1)
                return ""+ literal;
            else
                if(coefficient==1&&degree!=1)
                    return""+literal+"^"+degree;
                else
                    return (coefficient+literal+"^"+degree);
    }
}
