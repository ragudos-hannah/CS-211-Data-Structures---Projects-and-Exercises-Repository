/*
Name: Ragudos, Hannah T.
Date: 10/10/2023
 */

import java.util.*;

public class PolynomialArithmetic {
    Scanner keyboard = new Scanner(System.in);
    public void run() throws Exception{
        byte choice = 0;
        while ( choice != 6 ) {
            showMenu();
            choice = readChoice((byte) 1, (byte) 6);
            switch (choice){
                case 1:
                    evaluatePolynomial();
                    break;
                case 2:
                    addPolynomials();
                    break;
                case 3:
                    subtractPolynomials();
                    break;
                case 4:
                    multiplyPolynomials();
                    break;
                case 5:
                    dividePolynomials();
                    break;
                case 6:
                    System.out.println("Thank you for using this program.");
            } // end of swicth
        } // end of while
    } // end of run

    private byte readChoice(byte low, byte high) throws Exception{
        byte choice=0;
        System.out.print("Enter your choice<"+ low + "... " + high + ">: ");
        choice = (byte) readInteger(low, high);
        return choice;
    }
    public void showMenu() {
        System.out.println("-----------------------MENU--------------------------");
        System.out.println("1. Evaluate a polynomial");
        System.out.println("2. Add two polynomials");
        System.out.println("3. Subtract a polynomial from another polynomial");
        System.out.println("4. Multiply two polynomials");
        System.out.println("5. Divide a polynomial by another polynomial");
        System.out.println("6. Quit");
        System.out.println("--------------------------------------------------------");
    }
    public void evaluatePolynomial() throws Exception{
        System.out.println("You want to evaluate a polynomial.");
        Polynomial p = readPolynomial();
        System.out.println("The polynomial entered is " + p.toString());
        System.out.print("What is the value to be assigned to variable of the polynomial? ");
        double value= readDouble();

        System.out.println("The polynomial evaluates to : "+ p.evaluate(value));
        System.out.println("Press enter to continue.....");
        keyboard.nextLine();
    }
    private int readInteger(int low, int high){
        boolean validInput = false;
        int value=0;
        while (!validInput){
            try{
                value = Integer.parseInt(keyboard.nextLine());
                if ( value < low){
                    System.out.print("The number must not be lower than "+ low + ". ");
                }
                else if ( value > high){
                    System.out.print("The number must not be greater than "+ high +". ");
                } else {
                    validInput = true;
                }
            } catch (Exception x){
                System.out.println("You have to enter an integer from " + low + " to " + high + ".");
            }
        }
        return value;
    }
    private double readDouble(){
        boolean validInput = false;
        double value=0;
        while (!validInput){
            try{
                value = Double.parseDouble(keyboard.nextLine());
                validInput = true;
            } catch (Exception x){
                System.out.println("You have to enter a number.");
            }
        }
        return value;
    }
    public Polynomial readPolynomial() throws Exception{
        Polynomial p = new Polynomial();
        int degree=-1;
        boolean validDegree = false;
        char literalCoefficient = 'x';
        System.out.println("The polynomial should involve one variable/literal only.");
        do {
            System.out.print("What is the literal coefficient of the polynomial in one variable? ");
            literalCoefficient = keyboard.nextLine().charAt(0);
        } while (!Character.isAlphabetic(literalCoefficient));
        do {

            System.out.print("What is the degree of the polynomial? ");
            degree = readInteger(Integer.MIN_VALUE,Integer.MAX_VALUE);
            validDegree = true;
        } while (!validDegree);
        for (int x=degree; x>=0; x=x-1){
            Term term = readTerm(literalCoefficient, x);
            p.addTerm(term);
        }
        return p;
    }

    public Term readTerm(char literal, int degree)throws Exception{
        double nCoeff=0;
        System.out.print("Enter the numerical coefficient of the term with degree " + degree +": ");
        nCoeff = readDouble();
        Term term = new Term(nCoeff, literal, degree);
        return term;
    }
    public void addPolynomials() throws Exception {
        System.out.println("You want to add two polynomials.");
        System.out.println("Enter the first polynomial.");
        Polynomial p1 = readPolynomial();
        System.out.println("Enter the second polynomial.");
        System.out.println("Note that the second variable should have the same variable/literal as the first polynomial.");
                Polynomial p2 = readPolynomial();
        System.out.println("First polynomial : " + p1.toString());
        System.out.println("Second polynomial : " + p2.toString());
        if (p1.getTerms().get(0).getLiteral() == p2.getTerms().get(0).getLiteral()) {
            System.out.println("Sum of the polynomials : " + p1.add(p2));
        } else {
            System.out.println("The two polynomials cannot be added because they have different literals.");
        }
        System.out.println("Press enter to continue.....");
        keyboard.nextLine();
    }

    /**
     * Subtract the second polynomial entered by the user from the first and display the result.
     */
    public void subtractPolynomials() throws Exception {
        System.out.println("You want to subtract two polynomials.");
        System.out.println("Enter first polynomial:");
        Polynomial p1 = readPolynomial();
        System.out.println("Enter second polynomial:");
        Polynomial p2 = readPolynomial();
        System.out.println("First Polynomial : " + p1.toString());
        System.out.println("Second Polynomial : " + p2.toString());
        if (p1.getTerms().get(0).getLiteral() == p2.getTerms().get(0).getLiteral()) {
            System.out.println("Difference of the polynomials : " + p1.subtract(p2));
        } else {
            System.out.println("The two polynomials cannot be subtracted because they have different literals.");
        }
        System.out.println("Press enter to continue.....");
        keyboard.nextLine();
    }


    /**
     * Multiply two polynomials entered by the user and display the result.
     */
    public void multiplyPolynomials () throws Exception {
        System.out.println("You want to multiply two polynomials.");
        System.out.println("Enter first polynomial:");
        Polynomial p1 = readPolynomial();
        System.out.println("Enter second polynomial:");
        Polynomial p2 = readPolynomial();
        System.out.println("First Polynomial : " + p1.toString());
        System.out.println("Second Polynomial : " + p2.toString());
        if (p1.getTerms().get(0).getLiteral() == p2.getTerms().get(0).getLiteral()) {
            System.out.println("Product of the polynomials : " + p1.multiply(p2));
        } else {
            System.out.println("The two polynomials cannot be multiplied because they have different literals.");
        }
        System.out.println("Press enter to continue.....");
        keyboard.nextLine();
    }

    /**
     * Divide  two polynomials entered by the user and display the result.
     */
    public void dividePolynomials() throws Exception {
        System.out.println("You want to subtract two polynomials.");
        System.out.println("Enter first polynomial:");
        Polynomial p1 = readPolynomial();
        System.out.println("Enter second polynomial:");
        Polynomial p2 = readPolynomial();
        System.out.println("First Polynomial : " + p1.toString());
        System.out.println("Second Polynomial : " + p2.toString());
        if (p1.getTerms().get(0).getLiteral() == p2.getTerms().get(0).getLiteral()) {
            System.out.println("Quotient of the polynomials : " + p1.divide(p2));
        } else {
            System.out.println("The two polynomials cannot be divided because they have different literals.");
        }
        System.out.println("Press enter to continue.....");
        keyboard.nextLine();
    }
    public static void main(String[] args) {
        PolynomialArithmetic program;
        try {
            program = new PolynomialArithmetic();
            program.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    } // end of main
} // end of PolynomialArithmetic class

/*
SAMPLE RUN:
"C:\Program Files\Java\jdk-18.0.1.1\bin\java.exe" "-javaagent:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.1.3\lib\idea_rt.jar=54780:C:\Program Files\JetBrains\IntelliJ IDEA Community Edition 2022.1.3\bin" -Dfile.encoding=UTF-8 -classpath C:\Users\INSTRUCT-D522lab\IdeaProjects\RagudosHannah9342CS211MidtermIndividualProject1\out\production\RagudosHannah9342CS211MidtermIndividualProject1 PolynomialArithmetic
-----------------------MENU--------------------------
1. Evaluate a polynomial
2. Add two polynomials
3. Subtract a polynomial from another polynomial
4. Multiply two polynomials
5. Divide a polynomial by another polynomial
6. Quit
--------------------------------------------------------
Enter your choice<1... 6>: 1
You want to evaluate a polynomial.
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 2
Enter the numerical coefficient of the term with degree 2: 1
Enter the numerical coefficient of the term with degree 1: 3
Enter the numerical coefficient of the term with degree 0: 2
The polynomial entered is x^2 + 3.0x + 2.0
What is the value to be assigned to variable of the polynomial? 12
The polynomial evaluates to : 182.0
Press enter to continue.....

-----------------------MENU--------------------------
1. Evaluate a polynomial
2. Add two polynomials
3. Subtract a polynomial from another polynomial
4. Multiply two polynomials
5. Divide a polynomial by another polynomial
6. Quit
--------------------------------------------------------
Enter your choice<1... 6>: 2
You want to add two polynomials.
Enter the first polynomial.
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 1
Enter the numerical coefficient of the term with degree 1: 2
Enter the numerical coefficient of the term with degree 0: 3
Enter the second polynomial.
Note that the second variable should have the same variable/literal as the first polynomial.
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 2
Enter the numerical coefficient of the term with degree 2: 4
Enter the numerical coefficient of the term with degree 1: 2
Enter the numerical coefficient of the term with degree 0: 4
First polynomial :  2.0x + 3.0
Second polynomial :  4.0x^2 + 2.0x + 4.0
Sum of the polynomials :  4.0x^2 + 4.0x + 7.0
Press enter to continue.....

-----------------------MENU--------------------------
1. Evaluate a polynomial
2. Add two polynomials
3. Subtract a polynomial from another polynomial
4. Multiply two polynomials
5. Divide a polynomial by another polynomial
6. Quit
--------------------------------------------------------
Enter your choice<1... 6>: 3
You want to subtract two polynomials.
Enter first polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 1
Enter the numerical coefficient of the term with degree 1: 3
Enter the numerical coefficient of the term with degree 0: 2
Enter second polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 2
Enter the numerical coefficient of the term with degree 2: 3
Enter the numerical coefficient of the term with degree 1: 4
Enter the numerical coefficient of the term with degree 0: 5
First Polynomial :  3.0x + 2.0
Second Polynomial :  3.0x^2 + 4.0x + 5.0
Difference of the polynomials :  - 3.0x^2 - 1.0x - 3.0
Press enter to continue.....

-----------------------MENU--------------------------
1. Evaluate a polynomial
2. Add two polynomials
3. Subtract a polynomial from another polynomial
4. Multiply two polynomials
5. Divide a polynomial by another polynomial
6. Quit
--------------------------------------------------------
Enter your choice<1... 6>: 4
You want to multiply two polynomials.
Enter first polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 1
Enter the numerical coefficient of the term with degree 1: 2
Enter the numerical coefficient of the term with degree 0: 3
Enter second polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 2
Enter the numerical coefficient of the term with degree 2: 3
Enter the numerical coefficient of the term with degree 1: 4
Enter the numerical coefficient of the term with degree 0: 2
First Polynomial :  2.0x + 3.0
Second Polynomial :  3.0x^2 + 4.0x + 2.0
Product of the polynomials :  6.0x^3 + 17.0x^2 + 16.0x + 6.0
Press enter to continue.....

-----------------------MENU--------------------------
1. Evaluate a polynomial
2. Add two polynomials
3. Subtract a polynomial from another polynomial
4. Multiply two polynomials
5. Divide a polynomial by another polynomial
6. Quit
--------------------------------------------------------
Enter your choice<1... 6>: 5
You want to subtract two polynomials.
Enter first polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 2
Enter the numerical coefficient of the term with degree 2: 3
Enter the numerical coefficient of the term with degree 1: 4
Enter the numerical coefficient of the term with degree 0: 4
Enter second polynomial:
The polynomial should involve one variable/literal only.
What is the literal coefficient of the polynomial in one variable? x
What is the degree of the polynomial? 5
Enter the numerical coefficient of the term with degree 5: 6
Enter the numerical coefficient of the term with degree 4: 4
Enter the numerical coefficient of the term with degree 3: 3
Enter the numerical coefficient of the term with degree 2: 2
Enter the numerical coefficient of the term with degree 1: 1
Enter the numerical coefficient of the term with degree 0: 4
First Polynomial :  3.0x^2 + 4.0x + 4.0
Second Polynomial :  6.0x^5 + 4.0x^4 + 3.0x^3 + 2.0x^2 +x + 4.0
Quotient of the polynomials :  Quotient:  - 0.0 Remainder:  3.0x^2 + 4.0x + 4.0
Press enter to continue.....
 */