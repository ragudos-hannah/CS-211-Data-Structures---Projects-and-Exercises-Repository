/**
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9342 TF 9:00-10:30 AM
 * Date: 10/13/2023
 */

/**
 * Template for a cell of a two-dimensional array representing a maze for
 * simulating the movement of a mouse in a maze
 *
 * A cell has a row index and a column index
 * */
public class MazeCell{
    private int row;
    private int column;

    /**
     * Default constructor for MazeCell class
     */
    public MazeCell(){
        row=0;
        column=0;
    }

    /**
     * Parameters for MazeCell class
     * @param row
     * @param column
     */
    public MazeCell(int row, int column){
        this.row = row;
        this.column = column;
    }

    /**
     * Getter method for getting a row
     * @return
     */
    public int getRow(){
        return row;
    }

    /**
     * Getter method for getting a column
     * @return
     */
    public int getColumn(){
        return column;
    }

    /**
     * Setter method for setting a column
     * @param row
     */
    public void setRow(int row){
        this.row = row;
    }

    /**
     * Setter method fot setting column
     * @param column
     */
    public void setColumn(int column){
        this.column = column;
    }

    /**
     * Checker method for MazeCell
     * @param another
     * @return
     */
    public boolean sameAs(MazeCell another){
        return ( row == another.getRow() && column == another.getColumn());
    }
}
