/**
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9342 TF 9:00-10:30 AM
 * Date: 10/13/2023
 *
 * Sample Mouse Maze Puzzle.
 * The mouse(M) is positioned in a cell of the maze.
 * The mouse sequentially moves to open cells until the mouse reaches the exit cell E.
 * An open cell is marked by 0.
 * A closed cell is marked by 1.
 * by : Ragudos, Hannah T.
 *
 * Mouse Maze Solving Algorithm:
 *
 * 1. Initialization:
 * - Identify and store the positions of M (entryCell) and E (exitCell) in the maze.
 * - Initialize a Stack (mazeStack) to keep track of the path through the maze.
 * - Set currentCell to entryCell.
 *
 * 2. Path Finding Loop:
 * - While the mazeStack is not empty and the exitCell is not found:
 *      a. Pop a cell from the mazeStack and make it the currentCell.
 *      b. If the currentCell equals the exitCell, break the loop, and announce success.
 *      c. Else, mark the currentCell as visited.
 *      d. Identify the adjacent cells (up, down, left, right) from the currentCell.
 *      e. Push any adjacent cells that are open (not walls or already visited) and not
 *       already in mazeStack into mazeStack.
 *      f. If possible, visualize the maze to display the current path taken.
 *
 * 3. Result Evaluation:
 *      - If the exitCell is found, display the maze with the path taken and announce success.
 *      - If the mazeStack is empty and the exitCell is not found, announce failure.
 */

import java.io.*;
import java.lang.*;
import java.util.Stack;
import java.util.Scanner;
public class MouseMaze {

    private char[][] myMaze =

            {{'1','1','1','1','1','1'}, {'1','1','0','0','E','1'}, {'1','0','0','1','1','1'}, {'1','0','0','0','0','1'}, {'1','1','0','0','M','1'}, {'1','0','1','1','1','1'}};

    private int rows= myMaze.length;
    private int cols= myMaze[0].length;
    private MazeCell currentCell= null;
    private MazeCell exitCell = new MazeCell();
    private MazeCell entryCell= new MazeCell();

    private Stack<MazeCell> mazeStack = new Stack <>();
    private final char EXIT_MARKER = 'E';
    private final char ENTRY_MARKER = 'M';
    private final char VISITED = '.';
    private final char PASSAGE = '0';
    private final char WALL = '1';

    private FileReader fileReader;
    private BufferedReader bufferReader;
    private Scanner keyboard = new Scanner(System.in);

    public MouseMaze(){
        boolean foundEntryCell = false;
        boolean foundExitCell = false;


        /**
         * Look for the entry cell, the initial location of the mouse
         */

        for (int row=0; row<myMaze.length && !foundEntryCell; row++)
            for (int col = 0; col < myMaze[row].length && !foundEntryCell; col++){
                if (myMaze[row][col] == 'M'){
                    entryCell.setRow(row);
                    entryCell.setColumn(col);
                    foundEntryCell = true;
                }
            }

        /**
         * Look for the exit cell, the cell where the mouse may jump out of the maze
         */
        for (int row=0; row<myMaze.length && !foundExitCell; row++)
            for (int col = 0; col < myMaze[row].length && !foundExitCell; col++){

                if (myMaze[row][col] == 'E'){
                    exitCell.setRow(row);
                    exitCell.setColumn(col);
                    foundExitCell = true;
                }
            }
    } // end of Maze constructor

    /**
     * Show the maze with the current path followed by the mouse if any
     * @param myMaze
     */
    private void display(char[][] myMaze) {
        for (int row=0; row < myMaze.length; row++) {
            for (int col = 0; col < myMaze[row].length; col++)
                System.out.print(myMaze[row][col]);
            System.out.println();
        }
        System.out.println();
    }

    /**
     * Puts a cell with the given row and col index into a stack of cells to be visited
     * if the cell is marked as an open cell or exit cell
     * */
    private void pushUnvisited(int row, int col) {
        if (myMaze[row][col] == PASSAGE || myMaze[row][col] == EXIT_MARKER)
            mazeStack.push(new MazeCell(row,col));
    }

    /**
     * Let the mouse finds its way to the exit cell
     * */
    public void findWayOut() throws IOException {
        int row=0;
        int col=0;

        // Start from the entry cell, the cell where the mouse is initially placed
        currentCell = entryCell;
        System.out.println();
        display(myMaze);
        System.out.println("The above figure shows a maze where a mouse M is in.");
        System.out.println("The Mouse M should move to exhaustively find the Exit cell E");
        System.out.println("A cell marked 0 is an open cell, a cell marked by 1 is a closed cell");
        System.out.println("Keep pressing the enter key until success or failure is reached.");
        System.out.println("Find the way out.");

        keyboard.nextLine();
        while(!currentCell.equals(exitCell)){
            row = currentCell.getRow();
            col = currentCell.getColumn();
            if (currentCell.sameAs(exitCell)){
                display(myMaze);
                System.out.println("Success! Exit found");
                break;
            }
            if (!currentCell.sameAs(entryCell)) {
                myMaze[row][col] = VISITED;
                display(myMaze);
                System.out.println("Find the way out.");
                keyboard.nextLine();
            }

            /**
             * Create a Stack of the cells to be explored following the fixed order
             * up, down, left and right.
             *
             * A cell is included in the cell to be explored only if the cell is an open cell.
             * The pushUnvisited method is written such that it will only put the cell in the Stack if
             * the cell is open
             */

            pushUnvisited(row - 1, col); // note if cell up is open
            pushUnvisited(row + 1, col); // note if cell down is open
            pushUnvisited(row, col - 1); // note if cell at left is open
            pushUnvisited(row, col + 1); // note if cell at right is open

            if (mazeStack.isEmpty()) {
                display(myMaze);
                System.out.println("Failure: Exit cannot be reached");
                return;
            }
            else {
                currentCell = (MazeCell) mazeStack.pop(); // try to move to a reachable cell
            }
        }
    }

    public static void main(String[] args) {
        try {
            MouseMaze solver = new MouseMaze();
            solver.findWayOut();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
    } // end of main
} // end of class

/*
SAMPLE RUN:
111111
1100E1
100111
100001
1100M1
101111

The above figure shows a maze where a mouse M is in.
The Mouse M should move to exhaustively find the Exit cell E
A cell marked 0 is an open cell, a cell marked by 1 is a closed cell
Keep pressing the enter key until success or failure is reached.
Find the way out.


111111
1100E1
100111
100001
110.M1
101111

Find the way out.
111111
1100E1
100111
100001
11..M1
101111

Find the way out.

111111
1100E1
100111
10.001
11..M1
101111

Find the way out.

111111
1100E1
100111
10..01
11..M1
101111

Find the way out.

111111
1100E1
100111
10...1
11..M1
101111

Find the way out.

111111
1100E1
100111
1....1
11..M1
101111

Find the way out.

111111
1100E1
1.0111
1....1
11..M1
101111

Find the way out.

111111
1100E1
1..111
1....1
11..M1
101111

Find the way out.

111111
11.0E1
1..111
1....1
11..M1
101111

Find the way out.

111111
11..E1
1..111
1....1
11..M1
101111

Find the way out.

111111
11..E1
1..111
1....1
11..M1
101111

Success! Exit found

 */