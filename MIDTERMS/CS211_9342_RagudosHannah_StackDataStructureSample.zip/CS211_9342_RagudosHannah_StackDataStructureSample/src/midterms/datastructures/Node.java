/**
 *  Name: Ragudos, Hannah T.
 *  Date: 10/06/2023
 *  Class Code: 9342
 *
 * Algorithm and Data Structure Explanation for Node<T> class:
 *
 * Node<T> serves as the basic building block for linked data structures like linked lists, which is used in the stack implementation.
 * The Node class is a generic type, allowing it to store data of any object type while maintaining type safety.
 *
 * Data Members:
 * - `datum`: Stores the actual data of the node and is of generic type T.
 * - `next`: A reference to the next node in the linked structure, assisting in linking nodes sequentially.
 *
 * Methods:
 *
 * 1. Default Constructor `Node()`:
 *    - Initialize `datum` to null.
 *    - Initialize `next` reference to null.
 *    - Usage is ideal when creating a node without immediate data or link assignment.
 *
 * 2. Parameterized Constructor `Node(T datum, Node<T> next)`:
 *    - Assign `datum` with the provided data.
 *    - Assign `next` with the provided next node reference.
 *    - Useful for creating a node with known data and link.
 *
 * 3. `T getDatum()`:
 *    - Return the data stored in `datum`.
 *    - Provides access to private member `datum`.
 *
 * 4. `Node<T> getNext()`:
 *    - Return the reference stored in `next`.
 *    - Provides access to private member `next`.
 *
 * 5. `void setDatum(T datum)`:
 *    - Assign `datum` with the provided data.
 *    - Allows updating the data of a node post-instantiation.
 *
 * 6. `void setNext(Node<T> n)`:
 *    - Assign `next` with the provided node reference.
 *    - Facilitates linking or relinking to another node.
*/

package midterms.datastructures;

/**
 * The Node class represents a single node in a linked list, where each node contains a datum and a reference to the next node.
 * This class is generic, meaning it can store a datum of any type.
 *
 * @param <T> the type of elements stored in the node.
 */
public class Node<T> {
    private T datum;  // The datum of the node.
    private Node<T> next;  // The next node in the linked list.

    /**
     * Default constructor. Initializes an empty node with null datum and next reference.
     */
    public Node(){
        datum = null;
        next = null;
    }

    /**
     * Parameterized constructor. Initializes a node with the given datum and next reference.
     *
     * @param datum the datum to be stored in the node.
     * @param next the next node in the linked list.
     */
    public Node(T datum, Node<T> next){
        this.datum = datum;
        this.next = next;
    }

    /**
     * Gets the datum stored in the node.
     *
     * @return the datum of the node.
     */
    public T getDatum(){
        return datum;
    }

    /**
     * Gets the next node in the linked list.
     *
     * @return the next node.
     */
    public Node<T> getNext(){
        return next;
    }

    /**
     * Sets the datum of the node.
     *
     * @param datum the datum to be stored in the node.
     */
    public void setDatum(T datum){
        this.datum = datum;
    }

    /**
     * Sets the next node in the linked list.
     *
     * @param n the node to be set as the next node.
     */
    public void setNext(Node<T> n){
        next = n;
    }
} // end of Node class
