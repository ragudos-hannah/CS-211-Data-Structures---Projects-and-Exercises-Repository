/**
 *  Name: Ragudos, Hannah T.
 *  Date: 10/06/2023
 *  Class Code: 9342
 */

package midterms.datastructures;

/**
 * The StackUnderflowException class extends the Exception class, meaning that it
 * represents exceptions that can be thrown when there is an underflow in a stack.
 */

public class StackUnderflowException extends Exception {
    /**
     * Constructor method that takes a message as a parameter and passes it to
     * the constructor of the superclass (Exception).
     *
     * @param message A detailed message explaining the exception.
     */
    public StackUnderflowException(String message) {
        super(message);
    }
}
