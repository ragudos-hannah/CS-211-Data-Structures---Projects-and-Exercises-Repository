/**
 *  Name: Ragudos, Hannah T.
 *  Date: 10/06/2023
 *  Class Code: 9342
 *
 * Algorithm and Method Explanations for PalindromeChecker:
 *
 * PalindromeChecker is a class that provides functionality to check if a given string is a palindrome.
 * It uses stack data structure concept, by pushing characters into a stack and then comparing them
 * in a LIFO (Last In First Out) manner which naturally checks for palindrome properties.
 *
 * Methods:
 *
 * 1. `public void run() throws Exception`:
 *    - Description: Initiates the palindrome checking process by taking user input and providing output.
 *    - Algorithm:
 *      - Use Scanner to read a string input from the user.
 *      - Inform the user about the functionality of the application.
 *      - Check if the input string is a palindrome using isPalindrome() method.
 *      - Output whether the string is a palindrome or not based on the method return.
 *
 * 2. `public boolean isPalindrome(String string) throws StackUnderflowException`:
 *    - Description: Checks if a provided string is a palindrome.
 *    - Algorithm:
 *      - Initialize a stack of characters and an index to traverse through the string.
 *      - Push the first half of the string onto the stack.
 *      - If the string length is odd, skip the middle character.
 *      - Compare the remaining characters with the popped characters from the stack.
 *      - If all characters match and the stack is empty at the end, return true, indicating it is a palindrome.
 *      - Otherwise, return false
 *
 * Sample Output:
 *      This application helps you evaluate if a string is a palindrome or not
 *      Please enter the string: hannah
 *      hannah is a palindrome.
 */
package midterms.datastructures;

import java.util.Scanner;

/**
 * The `PalindromeChecker` class provides functionality to check
 * whether a given string is a palindrome. A palindrome is a word,
 * phrase, number, or other sequences of characters that reads
 * the same forward and backward (ignoring spaces, punctuation, and capitalization).
 *
 */
public class PalindromeChecker {

    /**
     * Entry point of the program.
     *
     * @param args Not used.
     */

    public static void main(String[] args) {
        // Create a PalindromeChecker instance and run the palindrome checking process
        PalindromeChecker myProgram;
        try {
            myProgram = new PalindromeChecker();
            myProgram.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.exit(0);
    }

    /**
     * Prompts user input and outputs if it is a palindrome.
     *
     * @throws Exception for any unexpected issues.
     */
    public void run() throws Exception {
        Scanner keyboard = new Scanner(System.in);

        // Inform the user about the application and prompt them to enter a string
        System.out.println("This application helps you evaluate if a string is a palindrome or not");
        System.out.print("Please enter the string: ");

        // Read user input
        String input = keyboard.nextLine();

        // Check if the input is a palindrome and display the result
        if (isPalindrome(input))
            System.out.println(input + " is a palindrome.");
        else
            System.out.println(input + " is not a palindrome.");
    }

    /**
     * Checks if `string` is a palindrome.
     *
     * @param string Input to check.
     * @return `true` if palindrome, otherwise `false`.
     * @throws StackUnderflowException if stack underflows.
     */
    public boolean isPalindrome(String string) throws StackUnderflowException {
        MyStack<Character> stack = new MyStack<>();
        int index = 0;

        // Push the first half of the string onto the stack
        while (index < string.length() / 2) {
            stack.push(string.charAt(index));
            index += 1;
        }

        // If the string length is odd, skip the middle character
        if (string.length() % 2 != 0) {
            index += 1;
        }

        // Compare the second half of the string with the popped values from the stack
        for (; index < string.length(); index++) {
            if (!stack.pop().equals(string.charAt(index))) {
                return false;
            }
        }

        // If the stack is empty, the string is a palindrome
        return stack.isEmpty();
    }
}
