/**
 * Name: Ragudos, Hannah T.
 * Date: 10/06/2023
 * Class Code: 9342
 *
 * Algorithm and Method Explanations for MyStackInterface:
 *
 * MyStackInterface is a generic interface that dictates the contract for any class implementing it as a stack.
 * It ensures that any class providing a stack implementation, regardless of the underlying data structure,
 * provides the fundamental stack operations in a type-safe manner.
 *
 * Methods:
 *
 * 1. `void push(T item)`:
 *    - Description: Should add an item onto the top of the stack.
 *    - Algorithm:
 *      - Accept an item of generic type T.
 *      - Place the item onto the top of the stack, ensuring that subsequent pop or peek operations retrieve it first.
 *
 * 2. `T pop() throws StackUnderflowException`:
 *    - Description: Should remove and return the top item of the stack.
 *    - Algorithm:
 *      - Check if the stack is empty and throw a StackUnderflowException if true.
 *      - Retrieve the item from the top of the stack.
 *      - Remove the top item from the stack, managing memory as appropriate.
 *      - Return the retrieved item.
 *
 * 3. `T peek() throws StackUnderflowException`:
 *    - Description: Should return the top item of the stack without removing it.
 *    - Algorithm:
 *      - Check if the stack is empty and throw a StackUnderflowException if true.
 *      - Retrieve and return the item from the top of the stack without modifying the stack.
 *
 * 4. `int size()`:
 *    - Description: Should return the number of items in the stack.
 *    - Algorithm:
 *      - Track and return the count of items currently present in the stack.
 *
 * 5. `boolean isEmpty()`:
 *    - Description: Should return a boolean indicating whether the stack is empty.
 *    - Algorithm:
 *      - Check if the stack has no items and return true if it is empty, otherwise false.
 */

package midterms.datastructures;

/**
 * The `MyStackInterface` serves as a template for stack data structures,
 * defining standard stack operations.
 *
 * @param <T> The type of elements in the stack
 */
public interface MyStackInterface<T> {

    /**
     * Pushes an item onto the top of this stack.
     *
     * @param item the item to be pushed onto this stack.
     */
    void push(T item);

    /**
     * Removes the item at the top of this stack and returns that object.
     *
     * @return The object at the top of this stack.
     * @throws StackUnderflowException if this stack is empty.
     */
    T pop() throws StackUnderflowException;

    /**
     * Looks at the object at the top of this stack without removing it from the stack.
     *
     * @return the object at the top of this stack.
     * @throws StackUnderflowException if this stack is empty.
     */
    T peek() throws StackUnderflowException;

    /**
     * Returns the number of items currently in the stack.
     *
     * @return the number of items in the stack.
     */
    int size();

    /**
     * Tests if this stack is empty.
     *
     * @return true if and only if this stack contains no items; false otherwise.
     */
    boolean isEmpty();

}