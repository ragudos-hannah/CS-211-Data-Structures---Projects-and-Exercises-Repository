/**
 * Name: Ragudos, Hannah T.
 * Date: 10/06/2023
 * Class Code: 9342
 *
 * Algorithm for MyStack class:
 *
 * The MyStack class implements the MyStackInterface, providing a generic stack functionality using a singly linked list.
 * The stack operations push, pop, and peek are implemented along with auxiliary methods to check the stack's size and emptiness.
 * A Node class is used to create the linked list, where each node contains data and a reference to the next node.
 * The stack is managed by maintaining a reference to the top node and updating it as elements are pushed and popped.
 *
 * Data Members:
 * - `top`: A reference to the top node in the stack, used to quickly access and manipulate the stack's top element.
 * - `count`: An integer counter that keeps track of the number of elements currently in the stack, enabling O(1) size retrieval.
 *
 * Methods:
 * 1. Constructor `MyStack()`:
 *    - Initialize `top` as null and `count` as 0.
 *
 * 2. `push(T item)`:
 *    - Create a new node with `item` as data and its `next` reference pointing to the current `top`.
 *    - Update `top` to point to the new node.
 *    - Increment `count` by 1.
 *
 * 3. `pop()`:
 *    - Ensure the stack is not empty, throwing a `StackUnderflowException` if it is.
 *    - Retrieve data from the node referenced by `top` to return later.
 *    - Update `top` to point to the next node in the stack.
 *    - Decrement `count` by 1.
 *    - Return the previously retrieved data.
 *
 * 4. `peek()`:
 *    - Ensure the stack is not empty, throwing a `StackUnderflowException` if it is.
 *    - Return the data from the node referenced by `top` without modifying the stack.
 *
 * 5. `size()`:
 *    - Return the value of `count`.
 *
 * 6. `isEmpty()`:
 *    - Return a boolean indicating whether `count` is 0.
 */

package midterms.datastructures;

/**
 * The `MyStack` class represents a generic stack data structure,
 * providing Last In, First Out (LIFO) access to elements.
 *
 * @param <T> The type of elements in the stack.
 */
public class MyStack<T> implements MyStackInterface<T> {
    private Node<T> top;  // Reference to the top node in the stack.
    private int count;  // Keeps track of the number of elements in the stack.

    /**
     * Default constructor initializes an empty stack.
     */
    public MyStack() {
        top = null;
        count = 0;
    }

    /**
     * The push method inserts an item onto the top of the stack.
     *
     * @param item The item to be added to the stack.
     */
    public void push(T item) {
        Node<T> newNode = new Node<T>(item, null);
        if (isEmpty()) {
            top = newNode;
        } else {
            newNode.setNext(top);
            top = newNode;
        }
        count += 1;
    }

    /**
     * The pop method removes and returns the top item of the stack.
     *
     * @return The top item of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    public T pop() throws StackUnderflowException {
        T topElement = null;
        if (isEmpty())
            throw new StackUnderflowException("Stack is empty");
        else {
            topElement = top.getDatum();
            if (count == 1) {
                top = null;
            } else {
                top = top.getNext();
            }
            count -= 1;
        }
        return topElement;
    }

    /**
     * The peek method returns the top item of the stack without removing it.
     *
     * @return The top item of the stack.
     * @throws StackUnderflowException if the stack is empty.
     */
    public T peek() throws StackUnderflowException {
        T topElement = null;
        if (isEmpty())
            throw new StackUnderflowException("Stack is empty");
        else {
            topElement = top.getDatum();
        }
        return topElement;
    }

    /**
     * Returns the number of elements in the stack.
     * @return The number of elements in the stack.
     */
    public int size() {
        return count;
    }

    /**
     * Checks whether the stack is empty.
     * @return True if the stack is empty, false otherwise.
     */
    public boolean isEmpty() {
        return count == 0;
    }
} // end of MyStack class




