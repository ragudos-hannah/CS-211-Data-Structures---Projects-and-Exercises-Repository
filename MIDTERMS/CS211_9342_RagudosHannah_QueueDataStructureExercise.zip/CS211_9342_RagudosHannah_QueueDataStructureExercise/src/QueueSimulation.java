/*
 * Name: Ragudos, Hannah T.
 * Class Code and Schedule: 9342 TF 9:00-10:30
 * Date: 10/17/2023
 */

import java.util.*;
/**
 * A typical Service system has servers and clients.
 *
 * An arriving client joins the queue of clients.
 * The server serves a client following First Come First Served discipline
 *
 * Algorithm for simulating a client-server queueing system:
 *
 * 1. Initialize random generators for client arrival times and service times.
 * 2. Set the average interarrival time for clients and the duration of the simulation.
 * 3. Create a queue to hold waiting clients.
 * 4. Initialize the server as idle.
 * 5. Let the simulation run for a set duration.
 * 6. Check if a client arrives at the current time.
 * 7. Print the arrival of the client.
 * 8. Create and add the client to the waiting queue.
 * 9. Print the waiting clients and their count.
 * 10. Update the ID for the next arriving client.
 * 11. Calculate the next client's arrival time.
 * 12. Check if the server is idle and if there's a client waiting:
 * 13. Serve the first client from the queue.
 * 14. Generate a random service time for the client.
 * 15. Print when the server will finish serving the client.
 * 16. If the current time matches the server's stop service time and it's not the start of the simulation:
 * 17. Indicate the server has finished serving a client.
 * 18. Set the server status to idle.
 * 19. End the simulation.
 */

/*
SAMPLE RUN:
Client 1 has arrived at time = 1.
Queue of Waiting Clients: N1(1)
Number of clients in the list = 1
Next client will arrive at time= 4
At time= 1 Server started serving client N1(1).
Server will be free at time = 5
Queue of Waiting Clients:
Client 2 has arrived at time = 4.
Queue of Waiting Clients: N2(4)
Number of clients in the list = 1
Next client will arrive at time= 5
Client 3 has arrived at time = 5.
Queue of Waiting Clients: N2(4) N3(5)
Number of clients in the list = 2
Next client will arrive at time= 8
At time = 5 Server finished serving client N1(1).
At time= 6 Server started serving client N2(4).
Server will be free at time = 8
Queue of Waiting Clients: N3(5)
Client 4 has arrived at time = 8.
Queue of Waiting Clients: N3(5) N4(8)
Number of clients in the list = 2
Next client will arrive at time= 12
At time = 8 Server finished serving client N2(4).
At time= 9 Server started serving client N3(5).
Server will be free at time = 13
Queue of Waiting Clients: N4(8)
Client 5 has arrived at time = 12.
Queue of Waiting Clients: N4(8) N5(12)
Number of clients in the list = 2
Next client will arrive at time= 14
At time = 13 Server finished serving client N3(5).
Client 6 has arrived at time = 14.
Queue of Waiting Clients: N4(8) N5(12) N6(14)
Number of clients in the list = 3
Next client will arrive at time= 17
At time= 14 Server started serving client N4(8).
Server will be free at time = 16
Queue of Waiting Clients: N5(12) N6(14)
At time = 16 Server finished serving client N4(8).
Client 7 has arrived at time = 17.
Queue of Waiting Clients: N5(12) N6(14) N7(17)
Number of clients in the list = 3
Next client will arrive at time= 18
At time= 17 Server started serving client N5(12).
Server will be free at time = 19
Queue of Waiting Clients: N6(14) N7(17)
Client 8 has arrived at time = 18.
Queue of Waiting Clients: N6(14) N7(17) N8(18)
Number of clients in the list = 3
Next client will arrive at time= 20
At time = 19 Server finished serving client N5(12).
Client 9 has arrived at time = 20.
Queue of Waiting Clients: N6(14) N7(17) N8(18) N9(20)
Number of clients in the list = 4
Next client will arrive at time= 22
At time= 20 Server started serving client N6(14).
Server will be free at time = 23
Queue of Waiting Clients: N7(17) N8(18) N9(20)
Client 10 has arrived at time = 22.
Queue of Waiting Clients: N7(17) N8(18) N9(20) N10(22)
Number of clients in the list = 4
Next client will arrive at time= 24
At time = 23 Server finished serving client N6(14).
Client 11 has arrived at time = 24.
Queue of Waiting Clients: N7(17) N8(18) N9(20) N10(22) N11(24)
Number of clients in the list = 5
Next client will arrive at time= 28
At time= 24 Server started serving client N7(17).
Server will be free at time = 25
Queue of Waiting Clients: N8(18) N9(20) N10(22) N11(24)
At time = 25 Server finished serving client N7(17).
At time= 26 Server started serving client N8(18).
Server will be free at time = 28
Queue of Waiting Clients: N9(20) N10(22) N11(24)
Client 12 has arrived at time = 28.
Queue of Waiting Clients: N9(20) N10(22) N11(24) N12(28)
Number of clients in the list = 4
Next client will arrive at time= 31
At time = 28 Server finished serving client N8(18).
At time= 29 Server started serving client N9(20).
Server will be free at time = 32
Queue of Waiting Clients: N10(22) N11(24) N12(28)
Client 13 has arrived at time = 31.
Queue of Waiting Clients: N10(22) N11(24) N12(28) N13(31)
Number of clients in the list = 4
Next client will arrive at time= 35
At time = 32 Server finished serving client N9(20).
At time= 33 Server started serving client N10(22).
Server will be free at time = 36
Queue of Waiting Clients: N11(24) N12(28) N13(31)
Client 14 has arrived at time = 35.
Queue of Waiting Clients: N11(24) N12(28) N13(31) N14(35)
Number of clients in the list = 4
Next client will arrive at time= 37
At time = 36 Server finished serving client N10(22).
Client 15 has arrived at time = 37.
Queue of Waiting Clients: N11(24) N12(28) N13(31) N14(35) N15(37)
Number of clients in the list = 5
Next client will arrive at time= 41
At time= 37 Server started serving client N11(24).
Server will be free at time = 37
Queue of Waiting Clients: N12(28) N13(31) N14(35) N15(37)
At time = 37 Server finished serving client N11(24).
At time= 38 Server started serving client N12(28).
Server will be free at time = 38
Queue of Waiting Clients: N13(31) N14(35) N15(37)
At time = 38 Server finished serving client N12(28).
At time= 39 Server started serving client N13(31).
Server will be free at time = 42
Queue of Waiting Clients: N14(35) N15(37)
Client 16 has arrived at time = 41.
Queue of Waiting Clients: N14(35) N15(37) N16(41)
Number of clients in the list = 3
Next client will arrive at time= 42
Client 17 has arrived at time = 42.
Queue of Waiting Clients: N14(35) N15(37) N16(41) N17(42)
Number of clients in the list = 4
Next client will arrive at time= 45
At time = 42 Server finished serving client N13(31).
At time= 43 Server started serving client N14(35).
Server will be free at time = 46
Queue of Waiting Clients: N15(37) N16(41) N17(42)
Client 18 has arrived at time = 45.
Queue of Waiting Clients: N15(37) N16(41) N17(42) N18(45)
Number of clients in the list = 4
Next client will arrive at time= 48
At time = 46 Server finished serving client N14(35).
At time= 47 Server started serving client N15(37).
Server will be free at time = 47
Queue of Waiting Clients: N16(41) N17(42) N18(45)
At time = 47 Server finished serving client N15(37).
Client 19 has arrived at time = 48.
Queue of Waiting Clients: N16(41) N17(42) N18(45) N19(48)
Number of clients in the list = 4
Next client will arrive at time= 50
At time= 48 Server started serving client N16(41).
Server will be free at time = 51
Queue of Waiting Clients: N17(42) N18(45) N19(48)
Client 20 has arrived at time = 50.
Queue of Waiting Clients: N17(42) N18(45) N19(48) N20(50)
Number of clients in the list = 4
Next client will arrive at time= 53

Process finished with exit code 0
 */

public class QueueSimulation {
    public static void main(String[] args) {
        QueueSimulation simulation;
        try {
            simulation = new QueueSimulation();
            simulation.run();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        System.exit(0);
    }

    public void run() {
        java.util.Random randomArrivalGenerator = new java.util.Random();
        java.util.Random randomServiceTimeGenerator = new java.util.Random();
        int averageInterarrival = 4;
        int simulationTimeDuration = 50; // length of simulation time
        double meanServiceTime = 5;

        // Generate random arrival of the first client
        int nextArrivalTime = randomArrivalGenerator.nextInt(averageInterarrival);

        // Create an ArrayList that will hold Queue of Clients
        Queue<Client> myListOfClients = new LinkedList<Client>();
        int clientId = 1;

        // Instantiate the server with no assigned client
        Server server = new Server();

        //Let simulation run from time =0 to a set length of time
        for (int time = 0; time <= simulationTimeDuration; time += 1) {

            // Check if a client arrives
            if (time == nextArrivalTime) {
                System.out.println("Client " + clientId + " has arrived at time = " + nextArrivalTime + ".");

                // Construct a client object and add the client object to the Queue of waiting clients
                Client newClient = new Client(clientId, nextArrivalTime);
                myListOfClients.add(newClient);

                // Show the Queue of waiting clients and the number of waiting clients
                showList(myListOfClients);
                System.out.println("Number of clients in the list = " + myListOfClients.size());

                // Prepare the id of the next client that will arrive next
                clientId += 1;

                // Generate the random arrival time of the next client
                nextArrivalTime += 1 + randomArrivalGenerator.nextInt(averageInterarrival);
                System.out.println("Next client will arrive at time= " + nextArrivalTime);
            }

            // Check if the server is idle and if there is a client waiting to be served
            if (server.isIdle() && !myListOfClients.isEmpty()) {

                // Let the server start serving the first client in the Queue
                Client clientToServe = myListOfClients.remove();
                server.setClient(clientToServe);
                server.setStartServiceTime(time);

                // Generate the random length of time for the server to serve the client
                int serveTime = randomServiceTimeGenerator.nextInt((int) meanServiceTime);
                int timeForServerToBecomeFree = time + serveTime;
                server.setStopServiceTime(timeForServerToBecomeFree);
                System.out.println("At time= " + time + " Server started serving client " + clientToServe + ".");
                System.out.println("Server will be free at time = " + timeForServerToBecomeFree);

                //Show the updated Queue of waiting clients
                showList(myListOfClients);
            }

            // Check if the server is to finish serving a client
            if (time == server.getStopServiceTime() && time > 0) {
                System.out.println("At time = " + time + " Server finished serving client " + server.getClient() + ".");

                // Let the status of the server be idle
                server.setClient(null);
            }
        } // end of for
    } // end of run

    public void showList(Queue<Client> a) {
        System.out.print("Queue of Waiting Clients: ");
        for (Client c : a) {
            System.out.print(c.toString() + " ");

        }
        System.out.println();
        return;
    }
} // end of class
