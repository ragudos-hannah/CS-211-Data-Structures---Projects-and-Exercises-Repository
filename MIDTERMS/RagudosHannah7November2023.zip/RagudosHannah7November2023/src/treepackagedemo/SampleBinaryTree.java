/**
 * Name: Ragudos, Hannah T.
 * Date: 11/07/2023
 *
 * SAMPLE RUN:
 *
 */

package treepackagedemo;

public class SampleBinaryTree {
    public static void main(String[] args) {
        SampleBinaryTree test;
        try {
            test = new SampleBinaryTree();
            test.run();
        } catch (Exception ex){
            ex.printStackTrace();
        }
        System.exit(0);
    } // end of main method
    public void run (){
        Tree<Integer> tree = new Tree<Integer>();
        Node<Integer> leaf1 = new Node<Integer>(21, null, null);
        Node<Integer> leaf2 = new Node<Integer>(28, null, null);
        Node<Integer> leaf3 = new Node<Integer>(5, null, null);
        Node<Integer> leaf4 = new Node<Integer>(27, null, null);
        Node<Integer> leaf5 = new Node<Integer>(3, null, null);
        Node<Integer> node3 = new Node<Integer>(53,leaf1,leaf2);
        Node<Integer> node2 = new Node<Integer>(66, node3,leaf3);
        Node<Integer> node4 = new Node<Integer>(55, leaf4, leaf5);

        tree.setRoot(new Node<Integer>(83, node2, node4));
        printPreOrder(tree.getRoot());
    } // end of run
    public void printPreOrder(Node<Integer> node){
        if (node != null) {
            System.out.print(node.getValue() + " ");
            printPreOrder(node.getLeft());
            printPreOrder(node.getRight());
        }
    }
}