/**
 * Name: Ragudos, Hannah T.
 * Date: 11/07/2023
 */

package treepackagedemo;

public class Tree<T> {
    private Node<T> root;
    public Tree(){
        root = null;
    }
    public void setRoot(Node<T> root){
        this.root = root;
    }
    public Node<T> getRoot(){
        return root;
    }
}