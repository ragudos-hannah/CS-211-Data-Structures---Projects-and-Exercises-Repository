/**
 * Name: Ragudos, Hannah T.
 * Date: 11/07/2023
*/

package treepackagedemo;

public class Node<T> {
    private T value;
    private Node<T> left;
    private Node<T> right;
    public Node(){
        value = null;
        left = null;
        right = null;
    }
    public Node (T value){
        this.value = value;
        left = null;
        right = null;
    }
    public Node(T value, Node<T> left, Node<T> right){
        this.value = value;
        this.left = left;
        this.right = right;
    }
    public void setValue(T value){
        this.value = value;
    }
    public void setLeft(Node<T> left) {
        this.left = left;
    }
    public void setRight(Node<T> right){
        this.right = right;
    }
    public T getValue(){
        return value;
    }
    public Node<T> getLeft(){
        return left;
    }

    public Node<T> getRight(){
        return right;
    }
}
