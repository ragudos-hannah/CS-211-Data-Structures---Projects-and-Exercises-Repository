import java.util.Objects;

/**
 * Class representing a person with a name and age. It implements Comparable for sorting purposes.
 */
public class Person implements Comparable<Person> {
    private String name;
    private int age;

    /**
     * Default constructor.
     */
    public Person() {
        this.name = "";
        this.age = 0;
    }

    /**
     * Constructs a new Person with a name and age.
     * @param name The name of the person.
     * @param age The age of the person.
     */
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    /**
     * Sets the name of this person.
     * @param name The new name of the person.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Sets the age of this person.
     * @param age The new age of the person.
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Returns the name of this person.
     * @return The name of this person.
     */
    public String getName() {
        return name;
    }

    /**
     * Returns the age of this person.
     * @return The age of this person.
     */
    public int getAge() {
        return age;
    }

    /**
     * Provides a string representation of this person.
     * @return A string representation of this person.
     */
    @Override
    public String toString() {
        return "(" + name + ", " + age + ")";
    }

    /**
     * Generates a hash code for this person.
     * @return The hash code of this person.
     */
    @Override
    public int hashCode() {
        return name.hashCode();
    }

    /**
     * Compares this person to another person.
     * @param other The person to compare to.
     * @return True if both persons are equal, false otherwise.
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) return true;
        if (other == null || getClass() != other.getClass()) return false;
        Person person = (Person) other;
        return age == person.age && Objects.equals(name, person.name);
    }

    /**
     * Compares this person with another person for order.
     * @param another The person to be compared.
     * @return A negative integer, zero, or a positive integer as this person
     *         is less than, equal to, or greater than the specified person.
     */
    @Override
    public int compareTo(Person another) {
        int nameComparison = name.compareTo(another.name);
        if (nameComparison != 0) {
            return nameComparison;
        }
        return Integer.compare(age, another.age);
    }
}
