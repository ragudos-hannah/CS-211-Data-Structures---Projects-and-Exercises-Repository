import java.util.*;

/**
 * This class demonstrates the use of a Hashtable to store Person objects and handle collisions.
 */
public class HashTableSampleA {

    /**
     * Prints all elements in the iterator, separated by commas.
     * @param iterator An iterator of any collection.
     */
    public static void print(Iterator iterator) {
        while (iterator.hasNext()) {
            System.out.print(iterator.next());
            if (iterator.hasNext()) {
                System.out.print(", ");
            }
        }
        System.out.println(); // To add a newline after printing all elements
    }

    /**
     * Main method to demonstrate the usage of Hashtable with Person objects.
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        Hashtable<Integer, Person> hashTable = new Hashtable<>();

        // Adding sample Person objects
        Person lord = new Person("Lord", 18);
        Person kathleen = new Person("Kathleen", 17);
        Person gracie = new Person("Gracie", 20);

        // Storing them in Hashtable with their hash code as the key
        hashTable.put(lord.hashCode(), lord);
        hashTable.put(kathleen.hashCode(), kathleen);
        hashTable.put(gracie.hashCode(), gracie);

        // Printing the Hashtable
        System.out.println("Current Hashtable: " + hashTable);

        // Demonstrating the iteration over entrySet, keySet, and values
        System.out.println("Iterating over entrySet:");
        print(hashTable.entrySet().iterator());

        System.out.println("Iterating over keySet:");
        print(hashTable.keySet().iterator());

        System.out.println("Iterating over values:");
        print(hashTable.values().iterator());

        // Search functionality
        System.out.print("Enter a name to search: ");
        String searchKey = keyboard.nextLine();
        System.out.println("Searching for: " + searchKey);

        Person searchPerson = new Person(searchKey, 0);
        Person foundPerson = hashTable.get(searchPerson.hashCode());

        if (foundPerson != null) {
            System.out.println("Person found: " + foundPerson);
        } else {
            System.out.println("Person not found.");
        }
    }
}
