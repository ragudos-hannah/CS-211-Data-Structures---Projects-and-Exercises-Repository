package graphdemo1;

import java.util.*;

/**
 * This class represents a Graph.
 */
public class Graph {
    private List<Node> nodes = new ArrayList<Node>();
    private int numberOfNodes = 0;

    /**
     * Check if there are at least 2 Nodes in the Graph.
     *
     * @return True if there are at least 2 Nodes, false otherwise.
     */
    public boolean checkForAvailability() {
        return this.numberOfNodes > 1;
    }

    /**
     * Add a Node to the Graph.
     *
     * @param node The Node to add to the Graph.
     */
    public void createNode(Node node) {
        this.nodes.add(node);
        this.numberOfNodes++; // a Node has been added
    }

    /**
     * Get the number of Nodes in the Graph.
     *
     * @return The number of Nodes in the Graph.
     */
    public int getNumberOfNodes() {
        return this.numberOfNodes;
    }
}
