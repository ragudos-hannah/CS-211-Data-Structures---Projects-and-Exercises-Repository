package graphdemo1;

import java.util.*;

/**
 * This class represents a Node in a graph.
 */
public class Node {
    private int id;
    private List<Edge> neighbours = new ArrayList<Edge>();

    /**
     * Constructor to create a Node.
     *
     * @param id The ID of the Node.
     */
    public Node(int id) {
        this.id = id;
    }

    /**
     * Get the ID of the Node.
     *
     * @return The ID of the Node.
     */
    public int getNodeld() {
        return this.id;
    }

    /**
     * Add a neighboring Edge to the Node.
     *
     * @param e The Edge to add as a neighbor.
     */
    public void addNeighbour(Edge e) {
        if (this.neighbours.contains(e)) {
            System.out.println("This edge has already been used for this node.");
        } else {
            System.out.println("Successfully added " + e);
            this.neighbours.add(e);
        }
    }

    /**
     * Get a list of all neighboring Edges.
     *
     * @return The list of neighboring Edges.
     */
    public List<Edge> getNeighbours() {
        System.out.println("List of all edges that node " + this.id + " has: ");
        System.out.println("==================================");
        for (int i = 0; i < this.neighbours.size(); i++) {
            System.out.println("ID of Edge: " + neighbours.get(i).getId() + "\nID of the first node: "
                    + neighbours.get(i).getIdOfStartNode() + "\nID of the second node: "
                    + neighbours.get(i).getIdOfEndNode());
            System.out.println();
        }
        System.out.println(neighbours);
        return this.neighbours;
    }

    /**
     * Override toString() to provide a string representation of the Node.
     *
     * @return A string representation of the Node.
     */
    @Override
    public String toString() {
        return "" + id;
    }
}
