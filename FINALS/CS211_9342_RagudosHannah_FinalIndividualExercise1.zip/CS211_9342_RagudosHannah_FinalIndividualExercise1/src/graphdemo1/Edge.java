package graphdemo1;

/**
 * This class represents an Edge in a graph.
 */
public class Edge {
    private Node start;
    private Node end;
    private double weight;
    private int id;

    /**
     * Get the ID of the Edge.
     *
     * @return The ID of the Edge.
     */
    public int getId() {
        return this.id;
    }

    /**
     * Get the starting Node of the Edge.
     *
     * @return The starting Node.
     */
    public Node getStart() {
        return this.start;
    }

    /**
     * Get the ID of the starting Node of the Edge.
     *
     * @return The ID of the starting Node.
     */
    public int getIdOfStartNode() {
        return this.start.getNodeld();
    }

    /**
     * Get the ending Node of the Edge.
     *
     * @return The ending Node.
     */
    public Node getEnd() {
        return this.end;
    }

    /**
     * Get the ID of the ending Node of the Edge.
     *
     * @return The ID of the ending Node.
     */
    public int getIdOfEndNode() {
        return this.end.getNodeld();
    }

    /**
     * Get the weight of the Edge.
     *
     * @return The weight of the Edge.
     */
    public double getWeight() {
        return this.weight;
    }

    /**
     * Constructor to create an Edge.
     *
     * @param s   The starting Node.
     * @param e   The ending Node.
     * @param w   The weight of the Edge.
     * @param id  The ID of the Edge.
     */
    public Edge(Node s, Node e, double w, int id) {
        this.start = s;
        this.end = e;
        this.weight = w;
        this.id = id;
    }

    /**
     * Override toString() to provide a string representation of the Edge.
     *
     * @return A string representation of the Edge.
     */
    @Override
    public String toString() {
        return "(" + start + "," + end + ")";
    }
}
