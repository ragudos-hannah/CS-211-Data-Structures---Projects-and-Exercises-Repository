import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Demonstrates the use of various Map implementations to organize data.
 * This class specifically shows how to populate and display contents of HashMap, TreeMap, and LinkedHashMap.
 */
public class TestHashMap {
    /**
     * Main method which populates different types of Maps and displays their contents.
     * @param args command line arguments
     */
    public static void main(String[] args) {
        // Create a HashMap and populate it with data
        Map<String, Integer> hashMap = new HashMap<>();
        populateMap(hashMap);

        // Display the entries in the HashMap
        System.out.println("Display entries in HashMap:");
        System.out.println(hashMap + "\n");

        // Create a TreeMap from the previous HashMap
        Map<String, Integer> treeMap = new TreeMap<>(hashMap);

        // Display the entries in the TreeMap in ascending order of key
        System.out.println("Display entries in ascending order of key:");
        System.out.println(treeMap + "\n");

        // Create a LinkedHashMap with access order
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>(16, 0.75f, true);
        populateMap(linkedHashMap);

        // Access some entries to demonstrate access order in LinkedHashMap
        linkedHashMap.get("Lewis");
        linkedHashMap.get("Anderson");

        // Display the age for Lewis
        System.out.println("The age for 'Lewis' is " + linkedHashMap.get("Lewis"));

        // Display the entries in LinkedHashMap in access order
        System.out.println("Display entries in LinkedHashMap:");
        System.out.println(linkedHashMap);
    }

    /**
     * Populates the provided map with sample data.
     * @param map the map to populate with data
     */
    private static void populateMap(Map<String, Integer> map) {
        map.put("Smith", 30);
        map.put("Anderson", 31);
        map.put("Lewis", 29);
        map.put("Cook", 29);
        map.put("Necesito", 35);
        map.put("Williams", 32);
        map.put("Tabaquero", 28);
        map.put("Guerrero", 45);
        map.put("Osorio", 20);
        map.put("Davis", 25);
    }
}
