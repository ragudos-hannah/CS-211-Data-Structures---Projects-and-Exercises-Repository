/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/17/2023
 */

/*
ALGORITHM for MyDoublyLinkedCircularListTester:

1. Define a class `MyDoublyLinkedCircularListTester`.
2. Create a new instance of `MyDoublyLinkedCircularList`.
3. Display the initial size of the list.
4. Add some elements to the list.
5. Display the entire list after additions.
6. Display the updated size of the list.
7. Search for certain elements in the list and display their indices.
8. Retrieve some elements from the list.
9. Delete certain elements from the list.
10. Display the entire list after deletions.
11. Display the size of the list after deletions.
 */

// START OF MySinglyLinkedCircularListTester.java
package prelim.DoublyLinkedCircularList;

import prelim.ListOverflowException;
import java.util.NoSuchElementException;

/**
 * MyDoublyLinkedCircularListTester is an executable class that tests and showcases the functionality
 * of the MyDoublyLinkedCircularList class.
 */
// This part was created on Sep. 17, 2023 by Hannah Ragudos
public class MyDoublyLinkedCircularListTester {

    /**
     * Main method to demonstrate the functionalities of the MyDoublyLinkedCircularList class.
     */
    // This part was created on Sep. 17, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        MyDoublyLinkedCircularList<String> list = new MyDoublyLinkedCircularList<>();

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Displaying the initial size of the list
        System.out.println("Initial size of the list: " + list.getSize());

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Inserting elements
        try {
            list.add("A");
            list.add("B");
            list.add("C");
            list.add("D");
        } catch (ListOverflowException e) {
            System.out.println(e.getMessage());
        } // end of try-catch

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Displaying the entire list after additions
        System.out.println("\nContents of the list after additions:");
        list.displayList();

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Displaying the updated size of the list
        System.out.println("\nUpdated size of the list: " + list.getSize());

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Searching for elements
        System.out.println("\nIndex of 'B': " + list.search("B"));
        System.out.println("Index of 'Z': " + list.search("Z"));

        // Retrieving elements
        try {
            System.out.println("\nRetrieved element for 'C': " + list.getElement("C"));
        } catch (NoSuchElementException e) {
            System.out.println(e.getMessage());
        } // end of try-catch

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Deleting elements
        System.out.println("\nDeleting 'A': " + (list.delete("A") ? "Successful" : "Failed"));
        System.out.println("Deleting 'Z': " + (list.delete("Z") ? "Successful" : "Failed"));

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Displaying the entire list after deletions
        System.out.println("\nContents of the list after deletions:");
        list.displayList();

        // This part was created on Sep. 17, 2023 by Hannah Ragudos
        // Displaying the size of the list after deletions
        System.out.println("\nSize of the list after deletions: " + list.getSize());
    } // end of main method
    
} //  END OF MySinglyLinkedCircularListTester.java

// SAMPLE RUN:
/*
Initial size of the list: 0

Contents of the list after additions:
A <-> B <-> C <-> D <-> (back to A)

Updated size of the list: 4

Index of 'B': 1
Index of 'Z': -1

Retrieved element for 'C': C

Deleting 'A': Successful
Deleting 'Z': Failed

Contents of the list after deletions:
B <-> C <-> D <-> (back to B)

Size of the list after deletions: 3
 */