/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for MyDoublyLinkedCircularList:

1. Define the class `MyDoublyLinkedCircularList` that implements `MyList` interface with generic type <E>.
2. Define private attributes:
   a. `head` to hold a reference to the first node in the list.
   b. `size` to keep track of the number of elements in the list.
3. Define a constructor:
   a. Initialize `head` to null.
   b. Set the initial size of the list to 0.
4. Define an inner class `Node`:
   a. Define attributes for data, next node, and previous node.
   b. Define a constructor to initialize the node with given data and set next and previous pointers to itself.
5. Define a method `getSize`:
   a. Return the current size of the list.
6. Define a method `add`:
   a. Create a new node with the given data.
   b. If the list is empty, set the head to the new node.
   c. Otherwise, link the last node to the new node and set the new node's previous to the last node.
   d. Increment the size.
7. Define a method `getElement`:
   a. Traverse the list to find the data.
   b. If found, return the data. Otherwise, throw a NoSuchElementException.
8. Define a method `delete`:
   a. Traverse the list to find the data.
   b. If found, adjust the pointers of adjacent nodes and decrement the size.
   c. Return true if the node was deleted, false otherwise.
9. Define a method `search`:
   a. Traverse the list to find the data.
   b. Return the index of the node if found, -1 otherwise.
10. Define a method `displayList`:
   a. Print all elements in the list.
*/

// START OF MyDoublyLinkedCircularList.java
package prelim.DoublyLinkedCircularList;

import prelim.ListOverflowException;
import prelim.MyList;

import java.util.NoSuchElementException;

/**
 * MyDoublyLinkedCircularList represents a doubly-linked circular list.
 * In a doubly-linked circular list, each node has pointers to both its next and previous nodes.
 * The last node's next pointer points back to the first node, and
 * the first node's previous pointer points to the last node.
 *
 * This class provides methods for adding, deleting, searching, and retrieving elements from the list,
 * as well as obtaining the size of the list.
 *
 * @param <E> The type of elements stored in this list.
 */
// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class MyDoublyLinkedCircularList<E> implements MyList<E> {

    private Node<E> head;
    private int size;

    /**
     * Default constructor initializes an empty list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public MyDoublyLinkedCircularList() {
        head = null;
        size = 0;
    }

    /**
     * Represents a node in the list.
     * Each node contains data and a reference to the next node in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    private static class Node<E> {
        E data;
        Node<E> next;
        Node<E> previous;

        /**
         * Constructs a new node with the given data.
         *
         * @param data The data stored in the node.
         */
        // This part was created on Sep. 12, 2023 by Hannah Ragudos
        public Node(E data) {
            this.data = data;
            this.next = this;
            this.previous = this;
        } // end of Node default constructor

    } // end of inner class Node

    /**
     * Retrieves the current size of the list.
     *
     * @return The number of elements in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    } // end of getSize method

    /**
     * Inserts a new element into the list.
     *
     * @param data The data to be added to the list.
     * @throws ListOverflowException if the list reaches its maximum capacity.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public void add(E data) throws ListOverflowException {
        Node<E> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
        } else {
            Node<E> temp = head.previous;
            temp.next = newNode;
            newNode.previous = temp;
            newNode.next = head;
            head.previous = newNode;
        } // end of if-else
        size++;
    } // end of add method

    /**
     * Retrieves an element from the list that matches the provided data.
     *
     * @param data The data to be searched in the list.
     * @return The element from the list that matches the provided data.
     * @throws NoSuchElementException if the data is not found in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public E getElement(E data) throws NoSuchElementException {
        Node<E> temp = head;
        if (head == null) throw new NoSuchElementException("List is empty.");
        do {
            if (temp.data.equals(data)) {
                return temp.data;
            } // end of if
            temp = temp.next;
        } while (temp != head);
        throw new NoSuchElementException("Element not found in the list.");
    } // end of getElement method

    /**
     * Deletes an element from the list that matches the provided data.
     *
     * @param data The data to be deleted from the list.
     * @return true if the element is successfully deleted, false otherwise.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public boolean delete(E data) {
        Node<E> temp = head;
        if (head == null) return false;
        do {
            if (temp.data.equals(data)) {
                if (temp == head) {
                    head = head.next;
                }
                temp.previous.next = temp.next;
                temp.next.previous = temp.previous;
                size--;
                return true;
            }
            temp = temp.next;
        } while (temp != head);
        return false;
    } // end of delete method

    /**
     * Searches for an element in the list.
     *
     * @param data The data to be searched in the list.
     * @return The index of the element in the list, or -1 if the element is not found.
     */
    @Override
    public int search(E data) {
        Node<E> temp = head;
        int index = 0;
        if (head == null) return -1;
        do {
            if (temp.data.equals(data)) {
                return index;
            }
            temp = temp.next;
            index++;
        } while (temp != head);
        return -1;
    } // end of search method

    /**
     * Helper method to display the entire list starting from the head.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public void displayList() {
        if (head == null) {
            System.out.println("The list is empty.");
            return;
        } // end of if
        Node<E> theList = head;
        do {
            System.out.print(theList.data + " <-> ");
            theList = theList.next;
        } while (theList != head);
        System.out.println("(back to " + theList.data + ")");
    } // end of do-while

}//  END OF MyDoublyLinkedCircularList.java
