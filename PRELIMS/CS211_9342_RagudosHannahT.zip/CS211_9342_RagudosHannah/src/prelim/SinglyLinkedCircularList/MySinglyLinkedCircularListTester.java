/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/15/2023
 */

/*
ALGORITHM for MySinglyLinkedCircularListTester:

1. Define the class `MySinglyLinkedCircularListTester`.
2. Initialize a new `MySinglyLinkedCircularList` object.
3. Print the initial size of the list.
4. Add several elements to the list.
5. Display the entire list.
6. Display the updated size of the list.
7. Search for specific elements in the list.
8. Retrieve several elements from the list.
9. Delete several elements from the list.
10. Display the entire list after deletions.
11. Display the final size of the list.
*/

// START OF MySinglyLinkedCircularListTester.java
package prelim.SinglyLinkedCircularList;

/**
 * MySinglyLinkedCircularListTester is an executable class that tests and showcases the functionality
 * of the MySinglyLinkedCircularList class.
 */
// This part was created on Sep. 15, 2023 by Hannah Ragudos
public class MySinglyLinkedCircularListTester {
    // This part was created on Sep.15, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        // Create an instance of the circular list
        MySinglyLinkedCircularList<String> list = new MySinglyLinkedCircularList<>();

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Add some elements
        System.out.println("Adding elements to the circular list:");
        String[] elements = {"A", "B", "C", "D"};
        for (String element : elements) {
            System.out.println("Adding: " + element);
            list.add(element);
        } // end of for

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Display the list
        System.out.println("\nContents of the circular list:");
        list.displayList();

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Search for an element
        String searchElement = "B";
        int index = list.search(searchElement);
        if (index != -1) {
            System.out.println("\nElement " + searchElement + " found at index: " + index);
        } else {
            System.out.println("\nElement " + searchElement + " not found in the list.");
        } // end of if-else

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Delete an element
        String deleteElement = "C";
        System.out.println("\nAttempting to delete element: " + deleteElement);
        if (list.delete(deleteElement)) {
            System.out.println(deleteElement + " deleted successfully.");
        } else {
            System.out.println("Failed to delete " + deleteElement);
        } // end of if-else

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Display the list after deletion
        System.out.println("\nContents of the circular list after deletion:");
        list.displayList();

        // This part was created on Sep.15, 2023 by Hannah Ragudos
        // Display the size of the list
        System.out.println("\nSize of the circular list: " + list.getSize());
    } // end of main method

} // START OF MySinglyLinkedCircularListTester.java

// SAMPLE RUN:
/*
Adding elements to the circular list:
Adding: A
Adding: B
Adding: C
Adding: D

Contents of the circular list:
A -> B -> C -> D -> back to A

Element B found at index: 1

Attempting to delete element: C
C deleted successfully.

Contents of the circular list after deletion:
A -> B -> D -> back to A

Size of the circular list: 3
 */
