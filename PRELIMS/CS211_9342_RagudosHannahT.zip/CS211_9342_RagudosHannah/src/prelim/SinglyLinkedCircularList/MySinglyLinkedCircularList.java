/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for MySinglyLinkedCircularList:

1. Define the class `MySinglyLinkedCircularList` implementing `MyList` interface.
2. Initialize `head` to null and `size` to 0.
3. Define the inner class `Node` with attributes `data` and `next`.
4. Implement `getSize` to return `size`.
5. Implement `add`:
   a. Create a new Node.
   b. If the list is empty, make the new node the head and circular.
   c. Else, traverse to the end and append the new node.
6. Implement `getElement`:
   a. Traverse the list.
   b. If node with the data is found, return its data.
   c. If not found, throw NoSuchElementException.
7. Implement `delete`:
   a. If head matches the data, remove it.
   b. Else, traverse the list and remove the node with the data.
   c. Adjust the size.
8. Implement `search`:
   a. Traverse the list.
   b. If node with the data is found, return its index.
   c. If not found, return -1.
9. Implement `display`:
   a. Traverse the list.
   b. Print each node's data.
*/

// START OF MySinglyLinkedCircularList.java
package prelim.SinglyLinkedCircularList;

import prelim.MyList;
import java.util.NoSuchElementException;

/**
 * MySinglyLinkedCircularList represents a singly-linked circular list.
 * A singly-linked circular list is a type of linked list in which the last node points back to the first node.
 *
 * This class provides methods for adding, deleting, searching, and retrieving elements from the list,
 * as well as obtaining the size of the list.
 *
 * @param <T> The type of elements stored in this list.
 */

// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class MySinglyLinkedCircularList<T> implements MyList<T> {

    private Node<T> head;
    private int size;

    /**
     * Default constructor initializes an empty list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public MySinglyLinkedCircularList() {
        head = null;
        size = 0;
    } // end of MySinglyLinkedCircularList default constructor

    /**
     * Represents a node in the list.
     * Each node contains data and a reference to the next node in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    private static class Node<T> {
        T data;
        Node<T> next;

        /**
         * Node constructor initializes a node with given data.
         * @param data The data to be stored in this node.
         *
         */
        public Node(T data) {
            this.data = data;
            this.next = null;
        } // end of Node default constructor

    } // end of inner class Node

    /**
     * Adds an element to the end of the list.
     *
     * @param data The data to add.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public void add(T data) {
        Node<T> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;
            head.next = head;  // Points to itself, making it circular
        } else {
            Node<T> temp = head;
            while (temp.next != head) {
                temp = temp.next;
            } // end of while
            temp.next = newNode;
            newNode.next = head;  // Last node pointing back to the first node
        } // end of else
        size++;
    } // end of add method

    /**
     * Retrieves the current size of the list.
     *
     * @return The number of elements in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    } // end of getSize method

    /**
     * Searches for an element in the list and returns it.
     *
     * @param data The data to search for in the list.
     * @return The found element.
     * @throws NoSuchElementException if the element is not found in the list.
     */
    @Override
    public T getElement(T data) throws NoSuchElementException {
        Node<T> current = head;
        if (head == null) {
            throw new NoSuchElementException("List is empty.");
        } // end of if
        do {
            if (current.data.equals(data)) {
                return current.data;
            } // end of if
            current = current.next;
        } while (current != head);
        throw new NoSuchElementException("Element not found in the list.");
    } // end of getElement method

    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    /**
     * Deletes a specified element from the list.
     *
     * @param data The data of the element to delete.
     * @return True if the element is deleted, false otherwise.
     */
    @Override
    public boolean delete(T data) {
        if (head == null) {
            return false;
        } // end of if
        if (head.data.equals(data)) {
            if (head.next == head) { // Only one element in the list
                head = null;
            } else {
                Node<T> temp = head;
                while (temp.next != head) {
                    temp = temp.next;
                } // end of while
                head = head.next;
                temp.next = head;
            } // end of if else
            size--;
            return true;
        } // end of if
        Node<T> current = head;
        while (current.next != head && !current.next.data.equals(data)) {
            current = current.next;
        } // end of while
        if (current.next.data.equals(data)) {
            current.next = current.next.next;
            size--;
            return true;
        } // end of if
        return false;
    } // end of delete method


    /**
     * Searches for a specified element in the list and returns its index.
     *
     * @param data The data to search for in the list.
     * @return The index of the element if found, -1 otherwise.
     */

    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int search(T data) {
        Node<T> current = head;
        int index = 0;
        if (head == null) {
            return -1;
        } // end of if
        do {
            if (current.data.equals(data)) {
                return index;
            } // end of if
            current = current.next;
            index++;
        } while (current != head);
        return -1;
    } // end of search method

    /**
     * Prints the contents of the list starting from the head.
     * The method traverses the list and prints each element until it reaches the head again, indicating the circular nature of the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public void displayList() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        } // end of if
        Node<T> temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);
        System.out.println("back to " + temp.data); // Indicate it's back to the head
    } // end of display method

}//  END OF MySinglyLinkedCircularList.java
