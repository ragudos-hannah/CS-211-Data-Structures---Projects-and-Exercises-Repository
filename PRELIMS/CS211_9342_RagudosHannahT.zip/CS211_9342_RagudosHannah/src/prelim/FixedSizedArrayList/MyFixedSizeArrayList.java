/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/07/2023
 */

/*
ALGORITHM for MyFixedSizeArrayList:
1. Define a class `MyFixedSizeArrayList` that implements `MyList` interface with generic type <E>.
2. Initialize MAX_SIZE to 5, which is the maximum size of the list.
3. Define a constructor that:
   a. Initializes a fixed-size array 'elements' of size MAX_SIZE.
   b. Sets the initial size of the list to 0.
4. Define a method `getSize` that:
   a. Returns the current size of the list.
5. Define a method `add` that:
   a. Checks if the current size is greater than or equal to MAX_SIZE.
      i. If true, throw a ListOverflowException indicating the list is full.
   b. Otherwise, add the data to the 'elements' array and increment the size.
6. Define a method `getElement` that:
   a. Calls the search method to find the index of the given data.
   b. If the index is -1 (not found), throw a NoSuchElementException.
   c. Otherwise, return the element at the found index.
7. Define a method `delete` that:
   a. Calls the search method to find the index of the given data.
   b. If the index is -1 (not found), return false.
   c. Otherwise, shift all elements after the index to fill the gap, decrement the size, set the last element to null, and return true.
8. Define a method `search` that:
   a. Iterates over the 'elements' array.
   b. If the current element matches the given data, return the index.
   c. If no match is found after iterating over all elements, return -1.
 */

// START OF MyFixedSizeArrayList.java

package prelim.FixedSizedArrayList;

import prelim.ListOverflowException;
import prelim.MyList;

import java.util.NoSuchElementException;

/**
 * MyFixedSizeArrayList provides an implementation of the MyList interface
 * using a fixed-size array as the data structure.
 * It supports basic operations like insertion, retrieval, deletion, and search.
 *
 * @param <E> The type of elements stored in the list.
 */
// This part was created on Sep. 07, 2023 by Hannah Ragudos
public class MyFixedSizeArrayList<E> implements MyList<E> {
    private static final int MAX_SIZE = 5;
    private final Object[] elements;
    private int size;

    /**
     * Default constructor initializes the array to a fixed size
     * and sets the initial size of the list to 0.
     */

    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    public MyFixedSizeArrayList() {
        elements = new Object[MAX_SIZE];
        size = 0;
    } // end of MyFixedSizeArrayList default constructor

    /**
     * Retrieves the number of elements currently in the list.
     *
     * @return The size of the list.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    } // end of getSize getter method

    /**
     * Adds a new element into the list. If the list is full,
     * it throws a ListOverflowException.
     *
     * @param data The element to be added.
     * @throws ListOverflowException If the list is already full.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public void add(E data) throws ListOverflowException {
        if (size >= MAX_SIZE) {
            throw new ListOverflowException("List is full");
        } // end of if condition
        elements[size++] = data;
    } // end of add method

    /**
     * Retrieves an element from the list based on matching data.
     * If the element is not found, it throws a NoSuchElementException.
     *
     * @param data The element to search for.
     * @return The matched element from the list.
     * @throws NoSuchElementException If the element isn't found.
     */
    // This part was created on Sep. 08, 2023 by Hannah Ragudos
    @SuppressWarnings("unchecked")
    @Override
    public E getElement(E data) throws NoSuchElementException {
        int index = search(data);
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        if (index == -1) {
            throw new NoSuchElementException("Element not found");
        } // end of if condition
        return (E) elements[index];
    } // end of getElement method

    // This part was created on Sep. 15, 2023 by Hannah Ragudos
    /**
     * Returns the entire array of elements in the list.
     *
     * @return The array of stored elements.
     */
    public Object[] getElements() {
        return elements;
    }



    /**
     * Deletes a specified element from the list. If successful, it returns true.
     * If the element is not found, it returns false.
     *
     * @param data The element to be deleted.
     * @return True if deletion is successful, false otherwise.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public boolean delete(E data) {
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        int index = search(data);
        if (index == -1) {
            return false;
        } // end of if condition

        // This part was modified by Hannah Ragudos on Sep. 09, 2023
        System.arraycopy(elements, index + 1, elements, index, size - index - 1);
        size--;
        elements[size] = null;
        return true;
    } // end of delete method

    /**
     * Searches for a specified element in the list.
     *
     * @param data The element to search for.
     * @return The index of the element if found, -1 otherwise.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public int search(E data) {
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        for (int i = 0; i < size; i++) {
            if (elements[i].equals(data)) {
                return i;
            } // end of if condition
        } // end of for loop
        return -1;
    } // end of search method

} // END OF MyFixedSizeArrayList.java
