/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/07/2023
 */

/*
ALGORITHM for MyFixedSizeArrayListTester:
1. Import  required packages and classes, such as java.util.NoSuchElementException and java.util.Scanner.
2. Define the class `MyFixedSizeArrayListTester`.
3. Inside the class:
   a. Define the main method as the entry point to the application.
   b. Initialize a new `MyFixedSizeArrayList` named `propertiesList` to store personal property details.
   c. Initialize a new Scanner object named `scanner` to get input from the user.
   d. Initialize a boolean variable named `exit` and set it to false. This will control the main loop of the application.
4. Create a main loop using a `while` statement that will run as long as `exit` is false:
   a. Display available options to the user:
      i. Add a personal property item.
      ii. View property details.
      iii. Delete a property item.
      iv. Exit the application.
   b. Prompt the user to choose an option and read their choice.
5. Use a `switch` statement to handle the user's choice:
   a. Case 1 - Add a personal property item:
      i. Display the format in which the user should enter the personal property details.
      ii. Prompt the user to enter property details.
      iii. Try to insert the entered property details to `propertiesList`.
         - If successful, display a success message.
         - If the list is full, catch a `ListOverflowException` and display an error message.
   b. Case 2 - View property details:
      i. Prompt the user to enter property details they wish to view.
      ii. Try to get the property details from `propertiesList`.
         - If found, display the details.
         - If not found, catch a `NoSuchElementException` and display an error message.
   c. Case 3 - Delete a property item:
      i. Prompt the user to enter property details they wish to delete.
      ii. Try to delete the entered property details from `propertiesList`.
         - If successful, display a success message.
         - If not found, display an error message.
   d. Case 4 - Exit the application:
      i. Set `exit` to true, which will end the main loop and subsequently end the application.
   e. Default case:
      i. If the user enters an invalid choice, display an error message.
6. Once the main loop is exited, display a "Thank you for using the tester for My Fixed Size Array List!" message to indicate the end of the application.
 */

// START OF MyFixedSizeArrayListTester.java
package prelim.FixedSizedArrayList;

import prelim.ListOverflowException;
import prelim.MyList;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

/**
 * MyFixedSizeArrayListTester is a command-line application that demonstrates
 * the usage of the MyFixedArrayList class. Users can interactively
 * insert, view, and delete details of their personal properties.
 */
// This part was created on Sep. 07, 2023 by Hannah Ragudos
public class MyFixedSizeArrayListTester {

    /**
     * The main method serves as the entry point to the application.
     * It provides an interactive menu for users to manage their personal properties.
     *
     * @param args Command-line arguments (not used in this application).
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        MyList<String> propertiesList = new MyFixedSizeArrayList<>();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        System.out.println("Welcome to the Personal Property Management Application!");

        // This part was created on Sep. 07, 2023 by Hannah Ragudos
        // This part was modified by Hannah Ragudos on Sep. 13, 2023
        while (!exit) {
            System.out.println("Options:");
            System.out.println("1. Add a personal property item");  // Add new item to the list.
            System.out.println("2. View property details");         // View details of a specific item.
            System.out.println("3. Delete a property item");        // Delete a specific item from the list.
            System.out.println("4. Exit");                          // Exit the application.

            int choice = -1;

            // This part was created on Sep. 08, 2023 by Hannah Ragudos
            // This part was modified by Hannah Ragudos on Sep. 12, 2023
            try {
                System.out.print("Choose an option: ");
                choice = scanner.nextInt();
                scanner.nextLine();

                // This part was modified by Hannah Ragudos on Sep. 13, 2023
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number for the option.");
                scanner.nextLine();
                continue;
            } // end of try-catch

            // This part was created on Sep. 08, 2023 by Hannah Ragudos
            switch (choice) {
                // This part was modified by Hannah Ragudos on Sep. 10, 2023
                case 1:
                    // Option 1: Insert a new personal property item into the list.
                    // The user is prompted to enter item details which are then added to the list.
                    // If the list is full, an error message is displayed.
                    System.out.println("Please use the following format for adding properties:");
                    System.out.println("Model Number, Color, Status, Purchase date, Estimated value.");
                    try {
                        System.out.print("Enter property details: ");
                        String property = scanner.nextLine();
                        propertiesList.add(property);
                        System.out.println("Property added successfully.");
                        System.out.printf("Properties stored: %d | Remaining space: %d\n", propertiesList.getSize(), 5 - propertiesList.getSize());
                    } catch (ListOverflowException e) {
                        System.out.println("Error: " + e.getMessage());
                    }  // end of try-catch
                    break;

                // This part was modified by Hannah Ragudos on Sep. 10, 2023

                    // Option 2: View a specific personal property's details from the list.
                    // The user is prompted to enter item details to search for.
                    // If found, the details are displayed; otherwise, an error message is shown.
                case 2:
                    System.out.print("Enter Model Number of property to view: ");
                    String searchProperty = scanner.nextLine();
                    String propertyDetails = propertiesList.getElement(searchProperty);
                    try {
                        String property = propertiesList.getElement(searchProperty);
                        System.out.println("Property found: " + property);
                    } catch (NoSuchElementException e) {
                        System.out.println("Error: " + e.getMessage());
                    } // end of try-catch
                    break;

                // This part was modified by Hannah Ragudos on Sep. 10, 2023
                case 3:
                    // Option 3: Delete a specific personal property from the list.
                    // The user is prompted to enter item details to be deleted.
                    // If successful, a confirmation message is shown; otherwise, an error message is displayed.
                    System.out.print("Enter property details to delete: ");
                    String deleteProperty = scanner.nextLine();
                    if (propertiesList.delete(deleteProperty)) {
                        System.out.println("Property deleted successfully.");
                    } else {
                        System.out.println("Property not found.");
                    } // end of if-else
                    break;

                // This part was modified by Hannah Ragudos on Sep. 10, 2023
                case 4:
                    // Option 4: Exit the application.
                    // This option sets the exit flag to true, leading to the termination of the loop and the application.
                    exit = true;
                    break;
                default:
                    // If the user enters an invalid option, a message is displayed,
                    // and they are prompted to choose again.
                    System.out.println("Invalid option. Please try again.");
            } // end of switch-case
        } // end of while

        // This part was modified by Hannah Ragudos on Sep. 13, 2023
        System.out.println("Thank you for using the Personal Property Management Application");

    } // end of main method
}// END OF MyFixedSizeArrayListTester.java

/*
SAMPLE RUN:
OWelcome to the Personal Property Management Application!

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 1
Please use the following format for adding properties:
Model Number, Color, Status, Purchase date, Estimated value.
Enter property details: A12345, Blue, New, 01-01-2023, P1200
Property added successfully.
Properties stored: 1 | Remaining space: 4

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 1
Please use the following format for adding properties:
Model Number, Color, Status, Purchase date, Estimated value.
Enter property details: B67890, Red, Used, 15-06-2020, P800
Property added successfully.
Properties stored: 2 | Remaining space: 3

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 1
Please use the following format for adding properties:
Model Number, Color, Status, Purchase date, Estimated value.
Enter property details: C45678, Green, Used, 05-03-2022, P600
Property added successfully.
Properties stored: 3 | Remaining space: 2

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 1
Please use the following format for adding properties:
Model Number, Color, Status, Purchase date, Estimated value.
Enter property details: D78901, Black, New, 12-12-2021, P1500
Property added successfully.
Properties stored: 4 | Remaining space: 1

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 1
Please use the following format for adding properties:
Model Number, Color, Status, Purchase date, Estimated value.
Enter property details: E23456, White, Used, 25-09-2023, P2000
Property added successfully.
Properties stored: 5 | Remaining space: 0
The property list is full. You cannot add more properties.

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 2
Enter Model Number of property to view: C45678
Property found: C45678, Green, Used, Purchase date: 05-03-2022, Estimated Value: P600

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 2
Enter Model Number of property to view: E23456
Property found: E23456, White, Used, Purchase date: 25-09-2023, Estimated Value: P2000

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 3
Enter Model Number of property to delete: D78901
Property deleted successfully.

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 3
Enter Model Number of property to delete: F12345
Property not found.

Options:
1. Add a personal property item
2. View property details
3. Delete a property item
4. Exit
Choose an option (1-4): 4
Thank you for using the Personal Property Management Application!

 */
