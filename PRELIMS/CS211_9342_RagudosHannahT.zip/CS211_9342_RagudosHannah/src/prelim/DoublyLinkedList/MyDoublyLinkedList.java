/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for MyDoublyLinkedList:

1. Define a class `MyDoublyLinkedList` that implements `MyList` interface with generic type <E>.
2. Define private attributes:
   a. `head` to hold a reference to the first node in the list.
   b. `tail` to hold a reference to the last node in the list.
   c. `size` to keep track of the number of elements in the list.
3. Define a constructor:
   a. Initialize `head` and `tail` to null.
   b. Set the initial size of the list to 0.
4. Define a method `getSize`:
   a. Return the current size of the list.
5. Define a method `add`:
   a. Create a new DoublyLinkedNode with the given data.
   b. If the list is empty:
      i. Set both `head` and `tail` to the new node.
   c. Otherwise:
      i. Link the current tail to the new node.
      ii. Update the tail to the new node.
   d. Increment the size.
6. Define a method `getElement`:
   a. Start from `head` and traverse the list.
   b. If a node with the given data is found, return its data.
   c. If no node is found, throw a NoSuchElementException.
7. Define a method `delete`:
   a. Start from `head` and traverse the list.
   b. If a node with the given data is found:
      i. Adjust the pointers of the adjacent nodes.
      ii. Decrement the size.
      iii. Return true.
   c. If no node is found, return false.
8. Define a method `search`:
   a. Start from `head` and traverse the list.
   b. Return the index of the found node or -1 if not found.
9. Define a method `getAllElements`:
   a. Traverse the list from `head` to `tail`.
   b. Append each node's data to a StringBuilder.
   c. Return the built string.

*/

// START OF MyDoublyLinkedList.java

package prelim.DoublyLinkedList;

import prelim.MyList;
import java.util.NoSuchElementException;

/**
 * MyDoublyLinkedList provides an implementation of the MyList
 * interface using a doubly-linked list structure.
 *
 * @param <E> The type of elements stored in this list.
 */

// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class MyDoublyLinkedList<E> implements MyList<E> {

    // These parts were created on Sep. 12, 2023 by Hannah Ragudos
    private DoublyLinkedNode<E> head;
    private DoublyLinkedNode<E> tail;
    private int size;

    /**
     * Default constructor initializes an empty list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public MyDoublyLinkedList() {
        this.head = null;
        this.tail = null;
        this.size = 0;
    } // end of MyDoublyLinkedList default constructor

    /**
     * Retrieves the number of elements currently in the list.
     * @return The size of the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    } // end of getSize getter method

    /**
     * Inserts a new element into the list at the end.
     * @param data The data to be inserted into the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public void add(E data) {
        DoublyLinkedNode<E> newNode = new DoublyLinkedNode<>(data);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            newNode.setPrevious(tail);
            tail = newNode;
        } // end of if-else
        size++;
    } // end of add method

    /**
     * Retrieves an element from the list based on the provided data.
     * @param data The data to search for in the list.
     * @return The found element.
     * @throws NoSuchElementException if the element is not found in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public E getElement(E data) throws NoSuchElementException {
        DoublyLinkedNode<E> current = head;
        while (current != null) {
            if (current.getData().equals(data)) {
                return current.getData();
            } // end of if
            current = current.getNext();
        } // end of while
        throw new NoSuchElementException("Element not found in the list.");
    } //end of getElement method

    /**
     * Deletes a specified element from the list.
     * @param data The data of the element to delete.
     * @return True if the element is deleted, false otherwise.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public boolean delete(E data) {
        DoublyLinkedNode<E> current = head;
        while (current != null) {
            if (current.getData().equals(data)) {
                if (current.getPrevious() != null) {
                    current.getPrevious().setNext(current.getNext());
                } else {
                    head = current.getNext();
                } // end of if-else
                if (current.getNext() != null) {
                    current.getNext().setPrevious(current.getPrevious());
                } else {
                    tail = current.getPrevious();
                } // end of if-else
                size--;
                return true;
            } // end of if
            current = current.getNext();
        } // end of if
        return false;
    } // end of delete method

    /**
     * Searches for a specified element in the list and returns its index.
     * @param data The data to search for in the list.
     * @return The index of the element if found, -1 otherwise.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int search(E data) {
        DoublyLinkedNode<E> current = head;
        int index = 0;
        while (current != null) {
            if (current.getData().equals(data)) {
                return index;
            } // end of if
            index++;
            current = current.getNext();
        } // end of while
        return -1;
    } // end of search method

    /**
     * Retrieves a string representation of all elements in the list.
     * @return A comma-separated string representing all elements in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public String getAllElements() {
        StringBuilder sb = new StringBuilder();
        DoublyLinkedNode<E> current = head;
        while (current != null) {
            sb.append(current.getData().toString());
            current = current.getNext();
            if (current != null) {
                sb.append(", ");
            } // end of if
        } // end of while
        return sb.toString();
    } // end of getAllElements method

} // END of MyDoublyLinkedList.java
