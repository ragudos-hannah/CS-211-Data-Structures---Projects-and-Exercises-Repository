/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/15/2023
 */

/*
ALGORITHM for MyDoublyLinkedListTester:

1. Import required packages and classes, such as prelim.DoublyLinkedList.MyDoublyLinkedList and java.util.NoSuchElementException.
2. Define the class `MyDoublyLinkedListTester`.
3. Inside the class:
   a. Define the main method as the entry point to the application.
   b. Initialize a new `MyDoublyLinkedList` of type String named `list` for family members.
   c. Print the initialization message for the list.
4. Insert family members' names into the list.
5. Display the current size of the list.
6. Display all the names present in the list.
7. Try to retrieve the name 'Hannah Ragudos' from the list:
   a. If successful, display the retrieved name.
   b. If not found, catch a `NoSuchElementException` and display an error message.
8. Search for the index of the name 'Lailah Ragudos' in the list and display the result.
9. Try to delete the name 'Walid Ragudos' from the list:
   a. If the deletion is successful, display a success message.
   b. If not, display a failure message.
10. Display all the names in the list after the deletion.
11. Search for the index of the name 'Walid Ragudos' after its deletion and display the result.
12. Attempt to retrieve a non-existent family member's name ('Abdul Ragudos'):
   a. If found, display the retrieved name.
   b. If not found, display an error message.
13. Conclude the main method execution.
*/

// START OF MyDoublyLinkedListTester.java
package prelim.DoublyLinkedList;

/**
 * MyDoublyLinkedListTester is a command-line application that demonstrates
 * the usage of the MyDoublyLinkedList class using family members' names.
 * Through this tester, users can interactively perform operations such as insertion, retrieval, deletion, and
 * search on a doubly-linked list of strings.
 */

// This part was created on Sep. 15, 2023 by Hannah Ragudos
public class MyDoublyLinkedListTester {
    /**
     * The main method serves as the entry point to the application.
     * It offers an interactive interface for users to manipulate a doubly linked list of strings (family members' names).
     * Users can perform operations such as insertion, retrieval, deletion, and search.
     *
     * @param args Command-line arguments (not used in this application).
     */
    // This part was created on Sep. 15, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        System.out.println("Initializing a new MyDoublyLinkedList of type String for family members");
        MyDoublyLinkedList<String> list = new MyDoublyLinkedList<>();

        // Insert family members' names
        System.out.println("\nInserting family members' names: Mansour Ragudos, Nur Jinnah Ragudos, Walid Ragudos, Hannah Ragudos, Lailah Ragudos, Samirah Ragudos, Sammara Ragudos");
        list.add("Mansour Ragudos");
        list.add("Nur Jinnah Ragudos");
        list.add("Walid Ragudos");
        list.add("Hannah Ragudos");
        list.add("Lailah Ragudos");
        list.add("Samirah Ragudos");
        list.add("Sammara Ragudos");

        // Display the size of the list
        System.out.println("\nSize of the list after inserts: " + list.getSize());

        // Display the list
        System.out.println("Names in the list: " + list.getAllElements());

        // Retrieve a name
        System.out.println("\nAttempting to retrieve the name 'Hannah Ragudos':");
        try {
            String member = list.getElement("Hannah Ragudos");
            System.out.println("Retrieved family member: " + member);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } // end of try-catch

        // Search for a family member's index
        System.out.println("\nSearching for the index of 'Lailah Ragudos':");
        int index = list.search("Lailah Ragudos");
        System.out.println("Index of 'Lailah Ragudos': " + index);

        // Delete a family member's name
        System.out.println("\nTrying to delete the name 'Walid Ragudos':");
        boolean isDeleted = list.delete("Walid Ragudos");
        System.out.println("Was 'Walid Ragudos' deleted? " + (isDeleted ? "Yes" : "No"));

        // Search for a family member's index after deletion
        System.out.println("\nSearching for the index of 'Walid Ragudos' after deletion:");
        int newIndex = list.search("Walid Ragudos");
        System.out.println("Index of 'Walid Ragudos': " + newIndex);

        // Attempt to retrieve a non-existent family member's name
        System.out.println("\nAttempting to retrieve a non-existent family member's name ('Abdul Ragudos'):");
        try {
            String missingMember = list.getElement("Abdul Ragudos");
            System.out.println("Retrieved family member: " + missingMember);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } // end of try-catch
    } // end of main method

} // END OF MyDoublyLinkedListTester.java

// SAMPLE RUN:
/*
Initializing a new MyDoublyLinkedList of type String for family members

Inserting family members' names: Mansour Ragudos, Nur Jinnah Ragudos, Walid Ragudos, Hannah Ragudos, Lailah Ragudos, Samirah Ragudos, Sammara Ragudos

Size of the list after inserts: 7
Names in the list: Mansour Ragudos, Nur Jinnah Ragudos, Walid Ragudos, Hannah Ragudos, Lailah Ragudos, Samirah Ragudos, Sammara Ragudos

Attempting to retrieve the name 'Hannah Ragudos':
Retrieved family member: Hannah Ragudos

Searching for the index of 'Lailah Ragudos':
Index of 'Lailah Ragudos': 4

Trying to delete the name 'Walid Ragudos':
Was 'Walid Ragudos' deleted? Yes

Searching for the index of 'Walid Ragudos' after deletion:
Index of 'Walid Ragudos': -1

Attempting to retrieve a non-existent family member's name ('Abdul Ragudos'):
Error: Element not found in the list.

 */