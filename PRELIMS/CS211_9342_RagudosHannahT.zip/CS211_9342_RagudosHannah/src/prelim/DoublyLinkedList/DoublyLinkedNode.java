/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for DoublyLinkedNode:
1. Define a class `DoublyLinkedNode` with generic type <T>.
2. Define private attributes:
 *    a. `data` to hold the data of the node.
 *    b. `next` to hold a reference to the next node in the list.
 *    c. `previous` to hold a reference to the previous node in the list.
3. Define a constructor:
 *    a. Initialize the node with given data, set `next` and `previous` to null.
4. Define a method `getData`:
 *    a. Return the data of this node.
5. Define a method `getNext`:
 *    a. Return the reference to the next node.
6. Define a method `setNext`:
 *    a. Set the reference of the next node to the given node.
7. Define a method `getPrevious`:
 *    a. Return the reference to the previous node.
8. Define a method `setPrevious`:
 *    a. Set the reference of the previous node to the given node.
 */

// START OF DoublyLinkedNode.java
package prelim.DoublyLinkedList;

/**
 * DoublyLinkedNode represents a node in a doubly-linked list.
 * Each node has a reference to the next and previous nodes in the list,
 * as well as a data element of generic type T.
 *
 * @param <T> The type of data the node holds.
 */
// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class DoublyLinkedNode<T> {
    public T data; // Data held by the node
    public DoublyLinkedNode<T> next; // Reference to the next node in the list
    public DoublyLinkedNode<T> previous; // Reference to the previous node in the list

    /**
     * Constructor initializes a node with the provided data.
     * @param data data to be held by the node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public DoublyLinkedNode(T data) {
        this.data = data;
        this.next = null;
        this.previous = null;
    } // end of DoublyLinkedNode constructor

    /**
     * Returns the data held by the node.
     * @return data of the node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public T getData() {
        return data;
    } // end of getData method

    /**
     * Returns the next node in the list.
     * @return next node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public DoublyLinkedNode<T> getNext() {
        return next;
    } // end of getNext method

    /**
     * Sets the next node in the list.
     * @param next next node to be set.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public void setNext(DoublyLinkedNode<T> next) {
        this.next = next;
    } // end of setNext method

    /**
     * Returns the previous node in the list.
     * @return previous node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public DoublyLinkedNode<T> getPrevious() {
        return previous;
    } // end of getPrevious method

    /**
     * Sets the previous node in the list.
     * @param previous previous node to be set.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public void setPrevious(DoublyLinkedNode<T> previous) {
        this.previous = previous;
    } // end of setPrevious method

} // END OF DoublyLinkedNode.java
