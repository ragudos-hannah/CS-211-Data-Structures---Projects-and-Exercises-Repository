/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for MySinglyLinkedList:

1. Define a class `MySinglyLinkedList` that implements `MyList` interface with generic type <E>.
2. Define private attributes:
   a. `head` to hold a reference to the first node in the list.
   b. `size` to keep track of the number of elements in the list.
3. Define a constructor:
   a. Initialize `head` to null.
   b. Set the initial size of the list to 0.
4. Define a method `getSize`:
   a. Return the current size of the list.
5. Define a method `add`:
   a. Create a new Node with the given data.
   b. If `head` is null (i.e., the list is empty):
      i. Set `head` to the new node.
   c. Otherwise:
      i. Traverse the list until the last node is reached.
      ii. Add the new node after the last node.
   d. Increment the size.
6. Define a method `getElement`:
   a. Start from the head node and traverse the list.
   b. If a node with the given data is found, return its data.
   c. If the end of the list is reached without finding the node, throw a NoSuchElementException.
7. Define a method `delete`:
   a. If `head` is null (list is empty), return false.
   b. If the data of the `head` node matches the given data:
      i. Update `head` to point to the next node.
      ii. Decrement the size.
      iii. Return true.
   c. Otherwise, traverse the list to find the node to be deleted and its previous node.
   d. If the node is found:
      i. Update the next pointer of the previous node to skip the node to be deleted.
      ii. Decrement the size.
      iii. Return true.
   e. If the node is not found, return false.
8. Define a method `search`:
   a. Start from the head node and traverse the list.
   b. For each node, compare its data with the given data.
   c. If a match is found, return the index.
   d. If no match is found after traversing the entire list, return -1.
9. Define a method `getAllElements`:
   a. Create an empty StringBuilder.
   b. Start from the head node and traverse the list.
   c. For each node, append its data to the StringBuilder.
   d. Return the string representation of the StringBuilder.
*/


// START OF MySinglyLinkedList.java

package prelim.SinglyLinkedList;

import prelim.MyList;
import java.util.NoSuchElementException;

/**
 * MySinglyLinkedList provides an implementation of the MyList
 * interface using a singly-linked list structure.
 *
 * @param <E> The type of elements stored in this list.
 */

// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class MySinglyLinkedList<E> implements MyList<E> {

    private Node<E> head;  // Reference to the first node in the list.
    private int size;      // The number of elements in the list.

    /**
     * Default constructor initializes an empty list.
     *
     * This constructor is responsible for setting up an empty list.
     * The head node reference is set to null, and the size counter is set to zero.
     */

    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public MySinglyLinkedList() {
        head = null;
        size = 0;
    } // end of MySinglyLinkedList default constructor

    /**
     * Retrieves the number of elements currently in the list.
     * This method returns the size of the list, which is tracked by an instance variable.
     *
     * @return The size of the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    }// end of getSize getter method

    /**
     * Inserts a new element into the list at the end.
     * This method creates a new Node with the given data. If the list is empty, the head
     * reference is updated to point to this new node. Otherwise, the method will traverse
     * to the end of the list and add the new node there.
     *
     * @param data The data to be inserted into the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public void add(E data) {
        Node<E> newNode = new Node<>(data);
        if (head == null) {
            head = newNode;

            // This part was modified by Hannah Ragudos on Sep.13, 2023
        } else {
            Node<E> temp = head;
            while (temp.getNext() != null) {
                temp = temp.getNext();
            } // end pf while loop
            temp.setNext(newNode);
        } // end of if-else
        size++;
    } // end of add method

    /**
     * Retrieves an element from the list based on the provided data.
     *
     * This method starts at the head of the list and traverses node by node,
     * searching for a node that contains the specified data. If found, the data is returned.
     * Otherwise, a NoSuchElementException is thrown.
     *
     * @param data The data to search for in the list.
     * @return The found element.
     * @throws NoSuchElementException if the element is not found in the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public E getElement(E data) throws NoSuchElementException {
        // This part was modified by Hannah Ragudos on Sep.13, 2023
        Node<E> temp = head;
        while (temp != null) {
            if (temp.getData().equals(data)) {
                return temp.getData();
            } // end of if
            temp = temp.getNext();
        } // end of while
        throw new NoSuchElementException("Element not found in the list.");
    } //end of getElement method

    /**
     * Deletes a specified element from the list.
     *
     * This method attempts to find and remove a node containing the specified data.
     * If the head node matches the data, the head reference is updated. If a subsequent
     * node matches, it is removed from the list. The size counter is decremented if a node
     * is removed.
     *
     * @param data The data of the element to delete.
     * @return True if the element is deleted, false otherwise.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public boolean delete(E data) {
        if (head == null) {
            return false;
        } // end of first if
        if (head.getData().equals(data)) {
            head = head.getNext();
            size--;
            return true;
        } // end of second if

        // This part was modified by Hannah Ragudos on Sep.13, 2023
        Node<E> current = head;
        while (current.getNext() != null && !current.getNext().getData().equals(data)) {
            current = current.getNext();
        } // end of while
        if (current.getNext() != null) {
            current.setNext(current.getNext().getNext());
            size--;
            return true;
        } // end of last if
        return false;
    } // end of delete method

    /**
     * Searches for a specified element in the list and returns its index.
     *
     * Starting at the head of the list and traversing node by node, this method
     * attempts to find a node containing the specified data. If found, the index
     * of the node is returned. Otherwise, the method returns -1.
     *
     * @param data The data to search for in the list.
     * @return The index of the element if found, -1 otherwise.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    @Override
    public int search(E data) {
        // This part was modified by Hannah Ragudos on Sep.13, 2023
        Node<E> temp = head;
        int index = 0;
        while (temp != null) {
            if (temp.getData().equals(data)) {
                return index;
            } // end of if
            temp = temp.getNext();
            index++;
        } // end of while
        return -1;
    } // end of search method

    /**
     * Retrieves a string representation of all elements in the list.
     *
     * This method builds a comma-separated string representation of all data
     * elements in the list.
     *
     * @return A string representing all elements in the list.
     */
    // This part was created on Sep. 13, 2023 by Hannah Ragudos
    public String getAllElements() {
        StringBuilder sb = new StringBuilder();
        Node<E> temp = head;
        while (temp != null) {
            // This part was modified by Hannah Ragudos on Sep.13, 2023
            sb.append(temp.getData().toString());
            temp = temp.getNext();
            if (temp != null) {
                sb.append(", ");
            } // end of if
        } // end of while
        return sb.toString();
    } // end of getAllElements method

}// END OF MySinglyLinkedList.java
