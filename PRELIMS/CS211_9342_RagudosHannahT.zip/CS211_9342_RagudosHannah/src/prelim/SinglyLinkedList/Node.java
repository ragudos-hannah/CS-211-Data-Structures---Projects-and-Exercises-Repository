/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/12/2023
 */

/*
ALGORITHM for Node:
1. Define a class `Node` with generic type <T>.
2. Define private attributes:
 *    a. `data` to hold the data of the node.
 *    b. `next` to hold a reference to the next node in the list.
 * 3. Define a constructor:
 *    a. Initialize the node with given data and set `next` to null.
 * 4. Define a method `getData`:
 *    a. Return the data of this node.
 * 5. Define a method `getNext`:
 *    a. Return the reference to the next node.
 * 6. Define a method `setNext`:
 *    a. Set the reference of the next node to the given node.
 */

// START OF Node.java
package prelim.SinglyLinkedList;


/**
 * Node represents a node in the singly-linked list.
 * Each node contains data and a reference to the next node in the sequence.
 *
 * @param <T> The type of data the node holds.
 */
// This part was created on Sep. 12, 2023 by Hannah Ragudos
public class Node<T> {
    private T data;
    private Node<T> next;

    /**
     * Constructor initializes a new node with the given data and a null next reference.
     *
     * @param data The data to store in the node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public Node(T data) {
        this.data = data;
        this.next = null;
    } // end of Node constructor

    /**
     * Getter for the data stored in this node.
     *
     * @return The data stored in the node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public T getData() {
        return data;
    } // end of getData getter method

    /**
     * Getter for the next node reference.
     *
     * @return The next node in the list, or null if there is no next node.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public Node<T> getNext() {
        return next;
    } // end of getNext getter method

    /**
     * Setter for the next node reference.
     *
     * @param nextNode The next node to set.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public void setNext(Node<T> nextNode) {
        this.next = nextNode;
    } // end of setNext setter method

} // END OF Node.java
