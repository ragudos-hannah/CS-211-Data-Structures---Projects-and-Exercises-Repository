/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/15/2023
 */
/*
ALGORITHM for MySinglyLinkedListTester:

1. Import required packages and classes, such as prelim.SinglyLinkedList.MySinglyLinkedList and java.util.NoSuchElementException.
2. Define the class `MySinglyLinkedListTester`.
3. Inside the class:
   a. Define the main method as the entry point to the application.
   b. Initialize a new `MySinglyLinkedList` of type Integer named `list`.
   c. Print the initialization message for the list.
4. Insert elements (10, 20, 30, 40, 50) into the list.
5. Display the current size of the list.
6. Display all the elements present in the list.
7. Try to retrieve the element 30 from the list:
   a. If successful, display the retrieved element.
   b. If not found, catch a `NoSuchElementException` and display an error message.
8. Search for the index of element 40 in the list and display the result.
9. Try to delete the element 30 from the list:
   a. If the deletion is successful, display a success message.
   b. If not, display a failure message.
10. Display all the elements in the list after the deletion.
11. Search for the index of element 30 in the list after its deletion and display the result.
12. Attempt to retrieve a non-existent element (100):
   a. If found, display the retrieved element.
   b. If not found, display an error message.
13. Insert more elements (60, 70, 80) into the list.
14. Display all the elements in the list after the new inserts.
15. Try to delete the head element (10) from the list:
   a. If the deletion is successful, display a success message.
   b. If not, display a failure message.
16. Display all the elements in the list after the deletion of the head element.
17. Display the final size of the list.
18. Conclude the main method execution.
 */

// START OF MySinglyLinkedListTester.java
package prelim.SinglyLinkedList;

/**
 * MySinglyLinkedListTester is a command-line application that demonstrates
 * the usage of the MySinglyLinkedList class. Through this tester, users can
 * interactively perform operations such as insertion, retrieval, deletion, and
 * search on a singly linked list of integers.
 */

// This part was created on Sep. 15, 2023 by Hannah Ragudos
public class MySinglyLinkedListTester {
    /**
     * The main method serves as the entry point to the application.
     * It offers an interactive interface for users to manipulate a singly linked list of integers.
     * Users can perform operations such as insertion, retrieval, deletion, and search.
     *
     * @param args Command-line arguments (not used in this application).
     */
    // This part was created on Sep. 15, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        System.out.println("Initializing a new MySinglyLinkedList of type Integer");
        MySinglyLinkedList<Integer> list = new MySinglyLinkedList<>();

        // Insert elements
        System.out.println("\nInserting elements: 10, 20, 30, 40, and 50");
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);

        // Display the size of the list
        System.out.println("\nSize of the list after inserts: " + list.getSize());

        // This part was modified by Hannah Ragudos on Sep.13, 2023
        // Display the list
        System.out.println("Elements in the list: " + list.getAllElements());

        // Retrieve an element
        System.out.println("\nAttempting to retrieve the element 30:");
        try {
            int element = list.getElement(30);
            System.out.println("Retrieved element: " + element);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } // end of try-catch

        // Search for an element's index
        System.out.println("\nSearching for the index of element 40:");
        int index = list.search(40);
        System.out.println("Index of 40: " + index);

        // Delete an element
        System.out.println("\nTrying to delete the element 30:");
        boolean isDeleted = list.delete(30);
        System.out.println("Was 30 deleted? " + (isDeleted ? "Yes" : "No"));
        System.out.println("List after deletion: " + list.getAllElements());

        // Search for an element's index after deletion
        System.out.println("\nSearching for the index of element 30 after deletion:");
        int newIndex = list.search(30);
        System.out.println("Index of 30: " + newIndex);

        // This part was modified by Hannah Ragudos on Sep. 16, 2023
        // Attempt to retrieve a non-existent element
        System.out.println("\nAttempting to retrieve a non-existent element (100):");
        try {
            int missingElement = list.getElement(100);
            System.out.println("Retrieved element: " + missingElement);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } // end of try-catch

        // This part was modified by Hannah Ragudos on Sep. 16, 2023
        // Inserting more elements
        System.out.println("\nInserting elements: 60, 70, and 80");
        list.add(60);
        list.add(70);
        list.add(80);
        System.out.println("List after inserts: " + list.getAllElements());

        // Deleting the head element
        System.out.println("\nTrying to delete the head element (10):");
        isDeleted = list.delete(10);
        System.out.println("Was 10 deleted? " + (isDeleted ? "Yes" : "No"));
        System.out.println("List after deletion: " + list.getAllElements());

        // Display the size of the list after all operations
        System.out.println("\nFinal size of the list: " + list.getSize());
    } // end of main method

} // END OF MySinglyLinkedListTester.java

// SAMPLE RUN:
/*
Initializing a new MySinglyLinkedList of type Integer

Inserting elements: 10, 20, 30, 40, and 50

Size of the list after inserts: 5
Elements in the list: 10, 20, 30, 40, 50

Attempting to retrieve the element 30:
Retrieved element: 30

Searching for the index of element 40:
Index of 40: 3

Trying to delete the element 30:
Was 30 deleted? Yes
List after deletion: 10, 20, 40, 50

Searching for the index of element 30 after deletion:
Index of 30: -1

Attempting to retrieve a non-existent element (100):
Error: Element not found in the list.

Inserting elements: 60, 70, and 80
List after inserts: 10, 20, 40, 50, 60, 70, 80

Trying to delete the head element (10):
Was 10 deleted? Yes
List after deletion: 20, 40, 50, 60, 70, 80

Final size of the list: 6

 */
