/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/05/2023
 */

// START OF ListOverflowException.java
package prelim;

/**
 * ListOverflowException is a custom exception that indicates a condition where
 * an attempt is made to add an element to a full list.
 */

// This part was created on Sep. 06, 2023 by Hannah Ragudos
public class ListOverflowException extends Exception {

    /**
     * Constructs a new ListOverflowException with the specified detail message.
     * @param message The detail message which provides more information about the exception.
     */
    public ListOverflowException(String message) {
        super(message);
    } // end of ListOverFlowException constructor

} // END OF ListOverflowException.java