/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/05/2023
 */

package prelim;
import java.util.NoSuchElementException;

// This part was created on Sep. 05, 2023 by Hannah Ragudos
public interface MyList<E> {
    public int getSize();
    public void add(E data) throws ListOverflowException;
    public E getElement(E data) throws NoSuchElementException;
    public boolean delete(E data);
    public int search(E data);
}
