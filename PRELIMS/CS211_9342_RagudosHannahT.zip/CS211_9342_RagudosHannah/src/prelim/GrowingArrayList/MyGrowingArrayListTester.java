/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/07/2023
 */

/*
ALGORITHM for MyGrowingArrayListTester:
1. Import required packages and classes, such as java.util.InputMismatchException, java.util.NoSuchElementException, and java.util.Scanner.
2. Define the class `MyGrowingArrayListTester`.
3. Inside the class:
   a. Define the main method as the entry point to the application.
   b. Initialize a new `MyGrowingArrayList` named `myList` to store task details.
   c. Initialize a new Scanner object named `scanner` to get input from the user.
   d. Initialize a boolean variable named `exit` and set it to false. This will control the main loop of the application.
4. Create a main loop using a `while` statement that will run as long as `exit` is false:
   a. Display available options to the user:
      i. Add completed task.
      ii. View task details.
      iii. Delete a task.
      iv. View all tasks.
      v. Exit the application.
   b. Prompt the user to choose an option and read their choice.
5. Use a `switch` statement to handle the user's choice:
   a. Case 1 - Add completed task:
      i. Prompt the user to enter task details.
      ii. Try to insert the entered task details to `myList`.
         - If successful, display a success message.
         - If the list overflows, catch a `ListOverflowException` and display an error message.
   b. Case 2 - View task details:
      i. Prompt the user to enter task details they wish to view.
      ii. Try to get the task details from `myList`.
         - If found, display the details.
         - If not found, catch a `NoSuchElementException` and display an error message.
   c. Case 3 - Delete a task:
      i. Prompt the user to enter task details they wish to delete.
      ii. Try to delete the entered task details from `myList`.
         - If successful, display a success message.
         - If not found, display an error message.
   d. Case 4 - View all tasks:
      i. Display all tasks in `myList`.
   e. Case 5 - Exit the application:
      i. Set `exit` to true, which will end the main loop and subsequently end the application.
   f. Default case:
      i. If the user enters an invalid choice, display an error message.
6. Once the main loop is exited, display a "Thank you for using the tester for My Fixed Size Array List!" message to indicate the end of the application.
 */

// START OF MyGrowingArrayListTester.java
package prelim.GrowingArrayList;

import prelim.ListOverflowException;
import prelim.MyList;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;



/**
 * MyGrowingArrayListTester is a command-line application that demonstrates
 * the usage of the MyGrowingArrayList class. Users can interactively
 * insert, view, and delete tasks for a course.
 */
// This part was created on Sep. 07, 2023 by Hannah Ragudos
public class MyGrowingArrayListTester {

    /**
     * The main method serves as the entry point to the application.
     * It provides an interactive menu for users to interact with the list.
     *
     * @param args Command-line arguments (not used in this application).
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    public static void main(String[] args) {
        MyList<String> myList = new MyGrowingArrayList<>();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        System.out.println("Welcome to the Task Management Application!");

        // This part was created on Sep. 07, 2023 by Hannah Ragudos
        // This part was modified by Hannah Ragudos on Sep. 09, 2023
        while (!exit) {
            System.out.println("Options:");
            System.out.println("1. Add completed task");   // Insert a new task into the list.
            System.out.println("2. View task details");     // View details of a specific task.
            System.out.println("3. Delete a task");         // Delete a specific task from the list.
            System.out.println("4. View all tasks");        // Display the entire list.
            System.out.println("5. Exit");                  // Exit the application.

            int choice = -1;

            // This part was created on Sep. 08, 2023 by Hannah Ragudos
            // This part was modified by Hannah Ragudos on Sep. 12, 2023
            try {
                System.out.print("Choose an option: ");
                choice = scanner.nextInt();
                scanner.nextLine();

                // This part was modified by Hannah Ragudos on Sep. 13, 2023
            } catch (InputMismatchException e) {
                System.out.println("Please enter a valid number for the option.");
                scanner.nextLine();
                continue;
            } // end of try-catch

            // This part was created on Sep. 08, 2023 by Hannah Ragudos
            switch (choice) {
                // This part was modified by Hannah Ragudos on Sep. 16, 2023
                case 1:
                    // Option 1: Insert a new task into the list.
                    // The user is prompted to enter task details which are then added to the list.
                    System.out.println("Please use the following format for adding task details:");
                    System.out.println("Project Name, Date Assigned, Date Completed");
                    try {
                        System.out.print("Enter task details: ");
                        String task = scanner.nextLine();
                        myList.add(task);
                        System.out.println("Task added successfully.");
                    } catch (ListOverflowException e) {
                        System.out.println("Error: " + e.getMessage());
                    } // end of try-catch
                    break;

                // This part was modified by Hannah Ragudos on Sep. 12, 2023
                case 2:
                    // Option 2: View a specific task's details from the list.
                    // The user is prompted to enter task details to search for.
                    // If found, the details are displayed; otherwise, an error message is shown.
                    System.out.print("Enter a project name to view its task details: ");
                    String searchTask = scanner.nextLine();
                    try {
                        String taskDetails = myList.getElement(searchTask);
                        System.out.println("Task found: " + taskDetails);
                    } catch (NoSuchElementException e) {
                        System.out.println("Error: " + e.getMessage());
                    } // end of try-catch
                    break;

                // This part was modified by Hannah Ragudos on Sep. 12, 2023
                case 3:
                    // Option 3: Delete a specific task from the list.
                    // The user is prompted to enter task details to be deleted.
                    // If successful, a confirmation message is shown; otherwise, an error message is displayed.
                    System.out.print("Enter task details to delete: ");
                    String deleteTask = scanner.nextLine();
                    if (myList.delete(deleteTask)) {
                        System.out.println("Task deleted successfully.");
                    } else {
                        System.out.println("Task not found.");
                    } // end of if-else
                    break;

                // This part was created on Sep. 12, 2023 by Hannah Ragudos
                case 4:
                    System.out.println("All tasks:");
                    System.out.println(((MyGrowingArrayList<String>) myList).getAllElements());
                    break;

                // This part was modified by Hannah Ragudos on Sep. 12, 2023
                case 5:
                    // Option 4: Exit the application.
                    // This option sets the exit flag to true, leading to the termination of the loop and the application.
                    exit = true;
                    break;

                // This part was modified by Hannah Ragudos on Sep. 13, 2023
                default:
                    // If the user enters an invalid option, a message is displayed,
                    // and they are prompted to choose again.
                    System.out.println("Invalid option. Please try again.");
            }  // end of switch-case
        } // end of while

        // This part was modified by Hannah Ragudos on Sep. 13, 2023
        System.out.println("Thank you for using the tester for My Fixed Size Array List!");

    } // end of main method
} // END OF MyGrowingArrayListTester.java

// SAMPLE RUN:
/*
Welcome to the Task Management Application!
Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 1
Enter task details: Math Assignment, Date Assigned: 01/01/2023, Date Completed: 05/01/2023
Task added successfully.

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 1
Enter task details: Science Project, Date Assigned: 02/01/2023, Date Completed: 10/01/2023
Task added successfully.

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 2
Enter task details to view: Science Project
Task found: Science Project, Date Assigned: 02/01/2023, Date Completed: 10/01/2023

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 4
All tasks:
Math Assignment, Date Assigned: 01/01/2023, Date Completed: 05/01/2023
Science Project, Date Assigned: 02/01/2023, Date Completed: 10/01/2023

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 3
Enter task details to delete: Math Assignment
Task deleted successfully.

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 4
All tasks:
Science Project, Date Assigned: 02/01/2023, Date Completed: 10/01/2023

Options:
1. Add completed task
2. View task details
3. Delete a task
4. View all tasks
5. Exit
Choose an option: 5
Thank you for using the tester for My Growing Arrat List Tester!!

 */
