/**
 * Name: Ragudos, Hannah T.
 * Schedule: TF 9:00 - 10:30
 * Date: 09/07/2023
 */

/*
ALGORITHM for MyGrowingArrayList:
1. Define a class `MyGrowingArrayList` that implements the `MyList` interface with generic type <E>.
2. Initialize `INITIAL_SIZE` to 5 as the starting size of the list.
3. Define a constructor that:
   a. Initializes a dynamically growing array 'listData' of size `INITIAL_SIZE`.
   b. Sets the initial size of the list to 0.
4. Define a method `getSize` that:
   a. Returns the current size of the list.
5. Define a method `insert` that:
   a. Checks if the current size is equal to the length of 'listData'.
      i. If true, create a new array of double the size and copy over the elements.
   b. Add the data to the 'listData' array and increment the size.
6. Define a method `getElement` that:
   a. Calls the search method to find the index of the given data.
   b. If the index is -1 (not found), throw a NoSuchElementException.
   c. Otherwise, return the element at the found index.
7. Define a method `delete` that:
   a. Calls the search method to find the index of the given data.
   b. If the index is -1 (not found), return false.
   c. Otherwise, shift all elements after the index to fill the gap, decrement the size, set the last element to null, and return true.
8. Define a method `search` that:
   a. Iterates over the 'listData' array.
   b. If the current element matches the given data, return the index.
   c. If no match is found after iterating over all elements, return -1.
9. Define a method `getAllElements` that:
   a. Iterates over the 'listData' array until the current size.
   b. Appends each element to a StringBuilder and returns the concatenated result.
 */

// START OF MyGrowingArrayList.java
package prelim.GrowingArrayList;

import prelim.MyList;

import java.util.NoSuchElementException;

/**
 * MyGrowingArrayList provides an implementation of the MyList interface
 * using an array that can dynamically grow as elements are added. The underlying
 * array doubles in size whenever it gets full, allowing for efficient space utilization.
 *
 * @param <E> The type of elements stored in the list.
 */
// This part was created on Sep. 07, 2023 by Hannah Ragudos
public class MyGrowingArrayList<E> implements MyList<E> {
    private static final int INITIAL_SIZE = 5;
    private Object[] listData;
    private int size;

    /**
     * Default constructor initializes the underlying array to a default initial size
     * and sets the initial size of the list to 0.
     */
    public MyGrowingArrayList() {
        listData = new Object[INITIAL_SIZE];
        size = 0;
    } // end of MyGrowingArrayList default constructor

    /**
     * Retrieves the number of elements currently in the list.
     *
     * @return The size of the list.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public int getSize() {
        return size;
    } // end of getSize getter method

    /**
     * Inserts a new element into the list. If the list is full, it creates a new array
     * of double the size, copies elements from the old array, and then inserts the new element.
     *
     * @param data The element to be added.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public void add(E data) {
        if (size == listData.length) {
            Object[] newList = new Object[listData.length * 2];
            System.arraycopy(listData, 0, newList, 0, size);
            listData = newList;
        } // end of if condition
        listData[size++] = data;
    } // end of insert method

    /**
     * Retrieves an element from the list based on matching data.
     * If the element is not found, it throws a NoSuchElementException.
     *
     * @param data The element to search for.
     * @return The matched element from the list.
     * @throws NoSuchElementException If the element isn't found.
     */
    // This part was created on Sep. 08, 2023 by Hannah Ragudos
    @SuppressWarnings("unchecked")
    @Override
    public E getElement(E data) throws NoSuchElementException {
        int index = search(data);
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        if (index == -1) {
            throw new NoSuchElementException("Element not found");
        } // end of if condition
        return (E) listData[index];
    } // end of getElement method

    /**
     * Deletes a specified element from the list. If successful, it returns true.
     * If the element is not found, it returns false.
     *
     * @param data The element to be deleted.
     * @return True if deletion is successful, false otherwise.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public boolean delete(E data) {
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        int index = search(data);
        if (index == -1) {
            return false;
        } // end of if condition

        // This part was modified by Hannah Ragudos on Sep. 09, 2023
        System.arraycopy(listData, index + 1, listData, index, size - index - 1);
        size--;
        listData[size] = null;
        return true;
    } // end of delete method

    /**
     * Searches for a specified element in the list and returns its index.
     *
     * @param data The element to search for.
     * @return The index of the element if found, -1 otherwise.
     */
    // This part was created on Sep. 07, 2023 by Hannah Ragudos
    @Override
    public int search(E data) {
        // This part was modified by Hannah Ragudos on Sep. 08, 2023
        for (int i = 0; i < size; i++) {
            if (listData[i].equals(data)) {
                return i;
            } // end of if condition
        } // end of for loop
        return -1;
    } // end of search method
    
    /**
     * Retrieves the entire list as a formatted string.
     *
     * @return A string representation of the list.
     */
    // This part was created on Sep. 12, 2023 by Hannah Ragudos
    public String getAllElements() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            sb.append(listData[i]).append("\n");
        } // end of for loop
        return sb.toString();
    } // end of getAllElements getter method

} // END OF MyGrowingArrayList.java
